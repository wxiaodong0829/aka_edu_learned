#include <stdio.h>
#include <time.h>
#include <Windows.h>
#include <conio.h>
#include <string.h>

int userflag;

typedef struct Datas
{
	char name[20];
	char id[19];
	long int acc;
	char password[7];
	double money;
	int accflag;		//�˺�״̬   [0Ϊ���� 1Ϊ�Ƕ���]
}UserData;

typedef struct admin
{
	long int adminacc;
	char password[7];
}AdminData;

long int zlplace;   // �ļ�λ��
char choose(void);
void user(void);
void admin(void);
void login(void);
void input(void);
int compare(long int temp_acc, char temp_pw[7]);
void yue(void);
void qukuan(void);
void zhuanzhang(void);
void reg(void);
void cunkuan(void);
void zhuangtai(void);
void gaimi(void);
void chaxiu(void);
void shanchu(void);