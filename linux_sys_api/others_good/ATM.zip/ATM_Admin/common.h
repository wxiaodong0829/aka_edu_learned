#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <Windows.h>

typedef struct admin
{
	long int adminacc;
	char password[10];
}AdminData;

char choose(void);