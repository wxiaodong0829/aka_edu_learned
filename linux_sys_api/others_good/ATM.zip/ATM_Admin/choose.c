#include "common.h"
char choose(void)
{
	char ch;
	do
	{
		ch = getche();
	}while( '\b' == ch );
	Sleep(2000);
	fflush(stdin);
	system("cls");
	return ch;
}