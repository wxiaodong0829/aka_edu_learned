/*	Sccsid @(#)draw.c	1.1 (gritter) 7/3/06	*/

#include "../draw.c"
