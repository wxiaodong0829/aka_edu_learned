/*	Sccsid @(#)otfdump_version.c	1.1 (gritter) 10/3/05	*/
#define	DUMP
#include "../version.c"
