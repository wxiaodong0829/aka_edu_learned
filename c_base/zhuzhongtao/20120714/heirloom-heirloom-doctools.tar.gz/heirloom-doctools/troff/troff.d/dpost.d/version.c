/*	Sccsid @(#)dpost_version.c	4.37 (gritter) 10/3/05	*/
#define	DPOST
#include "../../version.c"
