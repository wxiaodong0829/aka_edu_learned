/*************************************************************************
    > File Name   : main.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 09时53分22秒
 ************************************************************************/
#include "scp_server.h"

int main(int argc, char *argv[])
{
	int ret;
	ret = scp_server();
	if(ret == -1)
	{
		printf("Scp_server is something wrong ...\n");
		return -1;
	}

	return 0;
}


