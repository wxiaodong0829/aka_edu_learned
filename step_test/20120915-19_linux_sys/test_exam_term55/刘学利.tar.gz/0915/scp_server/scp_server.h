/*************************************************************************
    > File Name   : scp_server.h
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 09时56分42秒
 ************************************************************************/
#ifndef __SCP_SERVER_H__
#define __SCP_SERVER_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>

int scp_server(void);
int err_sys(const char *str);
void *thr(void *arg);
int download_file(int cfd);
int upload_file(int cfd);



#endif
