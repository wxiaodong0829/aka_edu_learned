/*************************************************************************
    > File Name   : error.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 10时10分10秒
 ************************************************************************/
#include "scp_server.h"

int err_sys(const char *str)
{
	perror(str);
	return -1;
}
