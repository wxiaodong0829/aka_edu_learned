/*************************************************************************
  > File Name   : upload_file.c
  > Function    : 
  > Author      : lxl
  > Mail        : 916311083@qq.com 
  > Created Time: 2012年09月15日 星期六 11时33分12秒
 ************************************************************************/
#include "scp_server.h"

int upload_file(int cfd)
{
	int nread, fd, ret;
	static int i = 1;
	char *p, *q;
	char buf[1024];

	/* 告诉客户端收到文件名， 并且当前目录下没有同名的文件 */
	write(cfd, "DOWNLOAD", strlen("DOWNLAOD"));

	/* 从套接字中获取数据，即文件名 */
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';
	q = malloc(nread+1);
	strncpy(q, buf, nread+1);

	while(1)
	{
		ret = access(buf, F_OK);
		if(ret == 0)	/* 有文件与要上传的文件同名 */
		{
			/* 告诉客户端收到文件名， 并且当前目录下没有同名的文件 */
			write(cfd, "OK_EXIST", strlen("OK_EXIST"));

			/* 不能覆盖 */
			p = rindex(q, '.');
			*p = '\0';
			sprintf(buf, "%s(%d).%s", q, i++, p+1);
			printf("%s\n", buf);
			free(q);
			continue;
		}

		/* 告诉客户端收到文件名， 并且当前目录下没有同名的文件 */
		write(cfd, "NO_EXIST", strlen("NO_EXIST"));

try_open:
		fd = open(buf, O_CREAT | O_WRONLY, 0644);
		if(fd == -1)
		{
			printf("Open: %s file failed ...\n", buf);
			goto try_open;
		}

		/* 从套接字中获取数据，并写到文件中 */
		while((nread = read(cfd, buf, 1024)) != 0)
			write(fd, buf, nread);

		close(fd);

		printf("Upload file successfully ...\n");

		break;
	}

	return 0;
}
