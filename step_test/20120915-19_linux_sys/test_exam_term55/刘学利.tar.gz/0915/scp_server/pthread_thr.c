/*************************************************************************
    > File Name   : pthread_thr.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 10时45分28秒
 ************************************************************************/
#include <pthread.h>
#include <semaphore.h>
#include "scp_server.h"

extern sem_t full, empty, left_pth;
extern volatile int cfd_tmp;

void *thr(void *arg)
{
	int cfd, nread, val;
	char buf[1024];

	/* 对信号量full加锁和empty解锁 */
	sem_wait(&full);
	cfd = cfd_tmp;
	sem_post(&empty);

	/* 从套接字中获取数据，判断是上传(UPLOAD)还是下载(DOWNLOAD) */
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';

	printf("%s\n", buf);
	if(strcmp(buf, "DOWNLOAD") == 0)	/* 下载文件 */
		download_file(cfd);
	if(strcmp(buf, "UPLOAD") == 0)	/* 上传文件 */
		upload_file(cfd);

	/* 关闭套接字 */
	close(cfd);

	/* 回收线程到线程池 */
	sem_getvalue(&left_pth, &val);
	if(val >= 20)
		return NULL;
	
	sem_post(&left_pth);

	return NULL;
}
