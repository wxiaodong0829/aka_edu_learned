/*************************************************************************
    > File Name   : scp_server.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 10时00分10秒
 ************************************************************************/
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <semaphore.h>

#include "scp_server.h"

//#define SERVER_IP "192.168.0.10"
#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8000

#define PTH_MAX 20

sem_t full, empty, left_pth;
volatile int cfd_tmp;

int scp_server(void)
{
	int sfd, cfd, ret, i;
	pthread_t tid;

/* 初始化地址结构 */
	struct sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr.s_addr);

/* 初始化信号量 */
	sem_init(&full, 0, 0);
	sem_init(&empty, 0, 1);
	sem_init(&left_pth, 0, PTH_MAX);

/* 创建套接字 */
	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd == -1)
		err_sys("socket error");

/* 绑定套接字和地址结构 */
	ret = bind(sfd, (struct sockaddr *)&server_addr, sizeof(server_addr));
	if(ret == -1)
		err_sys("bind error");

/* 监听套接字 */
	ret = listen(sfd, 20);
	if(ret == -1)
		err_sys("listen error");

/* 创建线程池 */
	for(i = 0; i < PTH_MAX; i++)
	{
		pthread_create(&tid, NULL, thr, NULL);
		if(ret == -1)
			err_sys("pthread_create error");
		pthread_detach(tid);	/*把线程变成分离状态*/
	}

	while(1)
	{
		/* 实例化套接字 */
		cfd = accept(sfd, NULL, NULL);	
		if(cfd == -1)
			err_sys("accept error");

		/* 对信号量empty加锁和full解锁 */
		sem_wait(&empty);
		cfd_tmp = cfd;
		sem_post(&full);

		/* 尝试对线程池里的先进进行加锁 */
		ret = sem_trywait(&left_pth);
		if(ret == -1)	
		{
			if(errno == EAGAIN)	/* 线程池中的线程已用完,创建新的线程 */
			{
				ret = pthread_create(&tid, NULL, thr, NULL);
				if(ret == -1)
					err_sys("pthread_create error");
				pthread_detach(tid);
			}
		}
	}

	return 0;
}
