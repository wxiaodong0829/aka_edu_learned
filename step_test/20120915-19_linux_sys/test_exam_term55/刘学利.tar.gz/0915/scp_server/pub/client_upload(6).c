/*************************************************************************
    > File Name   : client_upload.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 14时38分34秒
 ************************************************************************/
#include "scp_client.h"

int cli_upload_file(struct scp_client file, int cfd)
{
	int fd, nread;
	char buf[1024];
	char path[1024];
	char *p;

	p = rindex(file.client_filename, '/');
	sprintf(path, "%s/%s", file.server_filename, p + 1);

	/* 接受服务器发来的数据 */
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';
	if(strcmp(buf, "DOWNLOAD") == 0)
		;

	/* 发送给服务器要上传的文件名 */
	write(cfd, path, strlen(path));

	/* 接受服务器发来的数据,判断服务器段是否有同名文件 */
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';
	if(strcmp(buf, "OK_EXIST") == 0)
		printf("There is a file named %s\n", p+1);

try_open:
	fd = open(file.client_filename, O_RDONLY);
	if(fd == -1)	/* 打开文件失败, 尝试重新打开*/
	{
		printf("Open: %s file failed ...\n", file.client_filename);
		goto try_open;
	}

	/* 从文件中获取数据，并写到套接字中 */
	while((nread = read(fd, buf, 1024)) != 0)
		write(cfd, buf, nread);

	close(fd);
	close(cfd);

	printf("Upload file successfully ...\n");
		
	return 0;
}
