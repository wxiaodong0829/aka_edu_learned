/*************************************************************************
    > File Name   : download_file.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 10时59分28秒
 ************************************************************************/
#include "scp_server.h"

int download_file(int cfd)
{
	int nread, ret, fd;
	char buf[1024];

	/* 告诉客户端已收到“DOWNLOAD”*/
	write(cfd, "DOWNLOAD", strlen("DOWNLOAD"));

	/* 从套接字中获取数据， 即文件名 */
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';

	/* 判断文件是否存在 */
	ret = access(buf, F_OK);
	if(ret == 0)	/* 文件存在 */
	{
try_open:	/* 文件存在但打开失败，重新尝试打开 */
		fd = open(buf, O_RDONLY);
		if(fd == -1)
		{
			printf("Open: %s failed ...\n", buf);
			goto try_open;
		}
		while((nread = read(fd, buf, 1024)) != 0)	/* 从文件中获取数据，写到套接字中 */
			write(cfd, buf, nread);
		
		printf("download file successfully ...\n");
		close(fd);
//		close(cfd);
	}
	else	/* 文件不存在 */
	{
		write(cfd, "NO_EXIST", strlen("NO_EXIST"));
		printf("There is not a file named %s ...\n", buf);
//		close(cfd);
	}

	return 0;
}
