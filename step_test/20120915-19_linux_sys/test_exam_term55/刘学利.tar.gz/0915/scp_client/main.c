/*************************************************************************
    > File Name   : main.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 12时50分57秒
 ************************************************************************/
#include "scp_client.h"

int main(int argc, char *argv[])
{
	int ret;
	struct scp_client file;

	if(argc < 2)
	{
		printf("argc = %d\n", argc);
		return 0;
	}

	file = download_or_upload(file, argc, argv);

	ret = scp_client(file);
	if(ret == -1)
	{
		printf("scp_client error ...\n");
		return -1;
	}

	return 0;
}
