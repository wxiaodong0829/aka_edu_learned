/*************************************************************************
    > File Name   : scp_client.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 13时16分40秒
 ************************************************************************/
#include <sys/socket.h>
#include <arpa/inet.h>

#include "scp_client.h"

int scp_client(struct scp_client file)
{
	int cfd, ret;

	/* 初始化地址结构 */
	struct sockaddr_in server_addr;
	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(file.no_port);
	inet_pton(AF_INET, file.server_ip, &server_addr.sin_addr.s_addr);
#if 0
	server_addr.sin_port = htons(8000);
	inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr.s_addr);
#endif

	/* 创建套接字 */
	cfd = socket(AF_INET, SOCK_STREAM, 0);
	if(cfd == -1)
		err_sys("socket error");

	/* 创建连接 */
	ret = connect(cfd, (struct sockaddr *)&server_addr, sizeof(server_addr));
	if(ret == -1)
		err_sys("connect error");

	if(file.status == DOWNLOAD)	/* 下载文件 */
	{
		write(cfd, "DOWNLOAD", strlen("DOWNLOAD"));
		cli_download_file(file, cfd);
	}
	else if(file.status == UPLOAD)	/*上传文件*/
	{
		write(cfd, "UPLOAD", strlen("UPLOAD"));
		cli_upload_file(file, cfd);
	}

	close(cfd);

	/* 回收申请的空间 */
	destory(file);

	return 0;
}
