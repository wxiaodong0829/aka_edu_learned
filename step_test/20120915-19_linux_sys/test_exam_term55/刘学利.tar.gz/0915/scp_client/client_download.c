/*************************************************************************
  > File Name   : client_download.c
  > Function    : 
  > Author      : lxl
  > Mail        : 916311083@qq.com 
  > Created Time: 2012年09月15日 星期六 14时37分18秒
 ************************************************************************/
#include <time.h>
#include "scp_client.h"

int cli_download_file(struct scp_client file, int cfd)
{
	int fd, ret, nread;
	char *p, *q, *tmp;
	static int i = 1;
	char buf[1024];

	/* */
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';
	if(strcmp(buf, "DOWNLOAD") == 0)
		;
	/* 给服务器发送要下载的文件名 */
	write(cfd, file.server_filename, strlen(file.server_filename));
	nread = read(cfd, buf, 1024);
	buf[nread] = '\0';
	if(strcmp(buf, "NO_EXIST") == 0)
	{
		printf("There is not a file named %s in the server ...\n", buf);
		return 0;
	}

	p = rindex(file.server_filename, '/');
	sprintf(buf, "%s/%s", file.client_filename, p+1);

	while(1)
	{

		/* 判断当前目录下是否有与要下载文件同名 */	
		ret = access(buf, F_OK);
		if(ret == 0)	/* 有同名文件 */
		{
			printf("There is a file named %s ...\n", buf);
			tmp = malloc(sizeof(file.server_filename));
			strcpy(tmp, file.server_filename);

			q = rindex(file.server_filename, '.');	
			*q = '\0';
			srand(time(NULL));
			sprintf(buf, "%s/%s(%d).%s", file.client_filename, p, i++, q+1);

			strcpy(file.server_filename, tmp);
			free(tmp);

			continue;
		}
		/* 没有同名文件 */
try_open:
		fd = open(buf, O_CREAT | O_WRONLY, 0644);
		if(fd == -1)	/* 打开文件失败 */
		{
			printf("Open: %s file failed ...\n", file.server_filename);
			goto try_open;
		}

		/* 从套接字中获取数据，并写到文件中 */
		while((nread = read(cfd, buf, 1024)) != 0)
			write(fd, buf, nread);

		close(fd);

		printf("Download file successfully ...\n");

		break;
	}
	return 0;
}
