/*************************************************************************
    > File Name   : destory.c
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月16日 星期日 08时12分12秒
 ************************************************************************/
#include "scp_client.h"


void destory(struct scp_client file)
{
	free(file.client_filename);
	free(file.server_ip);
	free(file.server_filename);
}


