/*************************************************************************
  > File Name   : select.c
  > Function    : 
  > Author      : lxl
  > Mail        : 916311083@qq.com 
  > Created Time: 2012年09月15日 星期六 13时10分48秒
 ************************************************************************/
#include <sys/stat.h>

#include "scp_client.h"

void display(struct scp_client file)
{
	printf("%s\n", file.client_filename);
	printf("<%s>\n", file.server_ip);
	printf("%d\n", file.no_port);
	printf("%s\n", file.server_filename);
}

/* 分割出服务器IP(server_ip)、端口号no_port和要上传的文件名 */
static struct scp_client sep_ip_port(struct scp_client file, char *argv, char *client) 
{
	char *p, *q;
	int len;

	len = strlen(client) + 1;
	file.client_filename = malloc(len);
	strncpy(file.client_filename, client, len);	/* 把存放文件路径名存在申请的空间中 */

	/* 分割出服务器IP(server_ip) */
	p = argv;
	q = strstr(argv, ":");
	*q = '\0';
	len = strlen(p) + 1;
	file.server_ip = malloc(len);
	strncpy(file.server_ip, p, len);

	/* 分割出服务器端口号 */
	p = strstr(q+1, "/");
	*p = '\0';
	file.no_port = atoi(q+1);

	/* 分割出要上传的文件名 */
	len = strlen(p+1) + 1;
	file.server_filename = malloc(len);
	strncpy(file.server_filename, p+1, len);

	return file;
}

static struct scp_client down_or_up(struct scp_client file, int argc, char *argv[], struct stat st)
{
	if(S_ISDIR(st.st_mode))	/* 下载文件 */
		file = sep_ip_port(file, argv[1], argv[2]);
	else if(S_ISREG(st.st_mode))	/* 上传文件 */
		file = sep_ip_port(file, argv[2], argv[1]);
	
	return file;
}
struct scp_client download_or_upload(struct scp_client file, int argc, char *argv[])
{
	struct stat st_1, st_2;
	memset(&st_1, 0, sizeof(st_1));
	memset(&st_2, 0, sizeof(st_2));

	if(stat(argv[1], &st_1) == -1)
	{
		if(stat(argv[2], &st_2) == -1)
			err_sys("stat error"); 

		file = down_or_up(file, argc, argv, st_2);
		file.status = DOWNLOAD;
	}
	else
	{
		file = down_or_up(file, argc, argv, st_1);
		file.status = UPLOAD;
	}

#if 0
	display(file);
#endif

	return file;
}
