/*************************************************************************
    > File Name   : scp_client.h
    > Function    : 
    > Author      : lxl
    > Mail        : 916311083@qq.com 
    > Created Time: 2012年09月15日 星期六 12时51分49秒
 ************************************************************************/
#ifndef __SCP_CLIENT_H__
#define __SCP_CLIENT_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>

#define DOWNLOAD 1
#define UPLOAD 2

struct scp_client
{
	int no_port;
	int status;
	char *client_filename;
	char *server_ip;
	char *server_filename;
};

struct scp_client download_or_upload(struct scp_client file, int argc, char *argv[]);
int scp_client(struct scp_client file);
int err_sys(const char *str);
int cli_download_file(struct scp_client file, int cfd);
int cli_upload_file(struct scp_client file, int cfd);
void destory(struct scp_client file);

#endif
