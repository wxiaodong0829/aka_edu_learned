#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <regex.h>

int main(int argc, char** argv)
{
   int i = 0;
   int res;
   int sub_len;
   int cut_here;   /* 是一个位置标记 */
   char result[BUFSIZ];
   char err_buf[BUFSIZ];
   char* src = argv[1];   /* 源由命令行参数指定 */

   const char* pattern = "[+-](\\<[^,;]+\\>)";
   const char* pattern = "[0~9](3).[0~9](3).[0~9](3).[0~9]:";
   regex_t preg;
   
   regmatch_t pmatch[10];

   if( (res = regcomp(&preg, pattern, REG_EXTENDED)) != 0)
   {
      regerror(res, &preg, err_buf, BUFSIZ);
      printf("regcomp: %s\n", err_buf);
      exit(res);
   }

   while(1)
   {
      res = regexec(&preg, src, 10, pmatch, 0);
      if(res == REG_NOMATCH)
      {
         break;
      }
      for (i = 0; pmatch[i].rm_so != -1; i++)
      {
         sub_len = pmatch[i].rm_eo - pmatch[i].rm_so;
         memcpy(result, src + pmatch[i].rm_so, sub_len);
         result[sub_len] = 0;
         if(i == 0)
         {
            cut_here = pmatch[0].rm_eo;
            /* 下次匹配前src将从此处被截断 */
            printf("'%s' 成功被匹配, ", result);
         }
         else
            printf("其实我想要的是其中的 '%s' .", result);
      }
      putchar('\n');
      src += cut_here;
      /* 在src 中 "砍掉" 已经匹配的子串 */
   }
   regfree(&preg);
   return 0;
}

