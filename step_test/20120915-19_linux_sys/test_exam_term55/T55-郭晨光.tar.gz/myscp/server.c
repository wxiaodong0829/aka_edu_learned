#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_IP "127.0.0.1"
#define SERV_PORT 8000
#define MAX 1024

void sys_err(const char *str)
{
	perror(str);
	exit(1);
}

int main(void)
{
	int listenfd, connfd;
	struct sockaddr_in serv_addr;
	int n;

	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if(listenfd == -1)
		sys_err("socket error");

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERV_PORT);
	inet_pton(AF_INET, SERV_IP, &serv_addr.sin_addr.s_addr);

	n = bind(listenfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if (n == -1)
		sys_err("bind error");

	n = listen(listenfd, 20);
	if (n == -1)
		sys_err("listen error");

	printf("Accepting connections...\n");

	while (1) {
		char *filename;
		char buf[MAX];
		int fd;
		struct stat stat_buf;

		connfd = accept(listenfd, NULL, NULL);
		if (connfd == -1)
			sys_err("accept error");

		n = read(connfd, buf, 1024);
		buf[n] = '\0';

		if (strcmp(buf, "DOWN") == 0) {  //下载

			write(connfd, "OK", MAX);
			n = read(connfd, buf, MAX);
			buf[n] = '\0';

			stat(buf,&stat_buf);
			if (S_ISDIR(stat_buf.st_mode)) { //对路径进行判断是目录还是文件
				write(connfd, "DIR", MAX);
				close(connfd);
				continue;
			} else {

				filename = buf;
				fd = open(filename, O_RDONLY);
				if (fd == -1) {
					perror("open error");
					write(connfd, "NO", MAX);
					close(connfd);
					continue;
				}
				write(connfd, "FILE", MAX);
				//filename = buf;

				while ((n = read(fd, buf, MAX)))
					write(connfd, buf, n);

				close(fd);
				close(connfd);
				printf("down OK...\n");

			}

		} else if (strcmp(buf, "UP") == 0) {  //上传
			write(connfd, "OK", MAX);
			n = read(connfd, buf, MAX);
			buf[n] = '\0';
			filename = buf;

			fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
			write(connfd, "FILE_OK", MAX);

			while ((n = read(connfd, buf, MAX)))
				write(fd, buf, n);
			close(fd);
			close(connfd);
			printf("up OK...\n");
		}  
	}
	return 0;
}
