#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <arpa/inet.h>

#define SERV_PORT 8000
#define MAX 1024

void sys_err(const char *str)
{
	perror(str);
	exit(1);
}

int scp_down(char *dst, char *src)  //dst表示目的地，src表示来源
{
	struct  sockaddr_in serv_addr;
	int n, sfd, fd;
	char buf[MAX], *path;
	char *IP, *r, filename[MAX];

	IP = strtok(src, ":");
	path = strtok(NULL, ":");
	r = rindex(path, '/');

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sfd == -1)
		sys_err("socket error");

	memset(&serv_addr, 0, sizeof(serv_addr));  //初始化服务器地址结构
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERV_PORT);
	inet_pton(AF_INET, IP, &serv_addr.sin_addr.s_addr);

	n = connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if (n == -1)
		sys_err("connect error");

	write(sfd, "DOWN", MAX);
	n = read(sfd, buf, MAX);
	buf[n] = '\0';

	if (strcmp(buf, "OK") == 0) {  //判断服务器是否有应答

		write(sfd, path, MAX);  //将要下载的文件名告诉服务器
		n = read(sfd, buf, MAX);
		buf[n] = '\0';

		if (strcmp(buf, "NO") == 0) {  //文件是否存在
			printf("error, no found the file..\n");
			close(sfd);
			exit(1);
		} else if (strcmp(buf, "DIR") == 0){  //是否为目录文件
			printf("error, is a dir...\n");
			close(sfd);
			exit(1);
		} else if(strcmp(buf, "FILE") == 0) {  
			sprintf(filename, "%s%s", dst, r + 1);

			fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
			while ((n = read(sfd, buf, MAX)))
				write(fd, buf, n);
			close(fd);
			close(sfd);
			printf("down OK...\n");
		}
	}
	return 0;
}

int scp_up(char *dst, char *src)   //dst表示目的地,src表示来源
{
	int sfd, fd, n;
	char *IP, *r, filename[MAX];
	char buf[MAX], *path;
	struct stat stat_buf;
	struct sockaddr_in serv_addr;

	IP = strtok(dst, ":");
	path = strtok(NULL, ":");
	r = rindex(src, '/');

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sfd == -1)
		sys_err("socket error");

	stat(src, &stat_buf);
	if (S_ISDIR(stat_buf.st_mode)) {  //判断上传的是不是文件
		printf("input error is a dir...\n");
		exit(1);
	} else {
		memset(&serv_addr, 0, sizeof(serv_addr));  //初始化服务器的地址结构
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(SERV_PORT);
		inet_pton(AF_INET, IP, &serv_addr.sin_addr.s_addr);

		n = connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
		if (n == -1)
			sys_err("connect error");

		write(sfd, "UP", MAX);
		n = read(sfd, buf, MAX);
		buf[n] = '\0';

		if (strcmp(buf, "OK") == 0) {

			sprintf(filename, "%s%s", path, r + 1);
			write(sfd, filename, MAX);

			fd = open(src, O_RDONLY);
			n = read(sfd, buf, MAX);
			buf[n] = '\0';

			if (strcmp(buf, "FILE_OK") == 0)
				while((n = read(fd, buf, MAX)))
					write(sfd, buf, n);
			close(fd);
			close(sfd);
			printf("up OK...\n");
		}
	}

	return 0;
}

int main(int argc, char *argv[])
{
	char *p, *q;

	if (argc != 3) {
		printf("input error...\n");
		exit(0);
	}

	p = strstr(argv[1], ":");  //对参数操作，用于判断是上传还是下载
	q = strstr(argv[2], ":");

	if (p != NULL && q == NULL)        //下载
		scp_down(argv[2], argv[1]);

	else if ( p == NULL && q != NULL)    //上传
		scp_up(argv[2], argv[1]);
	else 
		printf("input error...\n");
	return 0;
}
