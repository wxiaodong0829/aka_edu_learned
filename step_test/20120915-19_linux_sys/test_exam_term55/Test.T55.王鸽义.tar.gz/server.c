#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_IP "127.0.0.1"
#define SERV_PORT 8000

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

int create_sock(char *addr, in_port_t port)
{
	int sfd, n;

	struct sockaddr_in serv_addr;

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd == -1)
		err_sys("socket error");

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port);
	inet_pton(AF_INET, addr, &serv_addr.sin_addr.s_addr);

	n = bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if(n == -1)
		err_sys("bind error");

	n = listen(sfd, 20);
	if(n == -1)
		err_sys("listen error");

	return sfd;
}

int main(void)
{
	int sfd, tfd;

	sfd = create_sock(SERV_IP, SERV_PORT);

	while(1)
	{
		int n;
		char buf[1024], fir_path[1024], end_path[1024], *p;

		tfd = accept(sfd, NULL, NULL);
		if(tfd == -1)
			err_sys("accept error");

		n = read(tfd, buf, 1024);
		buf[n] = '\0';

		p = strstr(buf, " ");
		strcpy(end_path, p + 1);
		*p = '\0';
		strcpy(fir_path, buf);

		n = isdigit(fir_path[0]);
		if(n == 1)
		{
			int fd;
			char filename[1024];

			p = index(fir_path, ':');
			strcpy(filename, p+1);

			fd = open(filename, O_RDONLY);
			while(n = read(fd, buf, 1024))
				write(tfd, buf, n);

			printf("downloading %s is over...\n", filename);

			close(tfd);
			close(fd);
		}else if(n == 0){
			struct stat st;
			int fd;
			char filename[1024];

			p = index(end_path, ':');
			strcpy(filename, p+1);

			stat(filename, &st);

			if(S_ISREG(st.st_mode))
			{
				fd = open(filename, O_WRONLY | O_TRUNC);
				if(fd == -1)
					err_sys("open error");

				while(n = read(tfd, buf, 1024))
					write(fd, buf, n);

				printf("uploading %s is over...\n", filename);

				close(tfd);
				close(fd);
			}else if(S_ISDIR(st.st_mode)){ 

				p = rindex(fir_path, '/');
				sprintf(filename, "%s/%s", filename, p);

				fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
				if(fd == -1)
					err_sys("open error");

				while(n = read(tfd, buf, 1024))
					write(fd, buf, n);

				printf("uploading %s is over...\n", filename);

				close(tfd);
				close(fd);
			}else
				printf("This filename is wrong...\n");
		}else
			printf("isdigit error...\n");
	}
	close(sfd);
	return 0;
}
