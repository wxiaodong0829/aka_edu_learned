#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>
#include <regex.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_PORT 8000
#define MAXSIZE   1024
#define NR        128

regex_t pre;

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

int match_str(const char *pattern, char *str)
{
	int n;
	char buf[NR];
	n = regcomp(&pre, pattern, REG_EXTENDED |  REG_ICASE | REG_NOSUB);
	if (n != 0) {
		regerror(n, &pre, buf, sizeof(buf));
		fprintf(stderr, "%s:pattern '%s'\n", buf, str);
		return 1;
	}
	n = regexec(&pre, str, 0, NULL, REG_EXTENDED | REG_ICASE | REG_NOSUB);
	if (n != 0) {
		regerror(n, &pre, buf, sizeof(buf));
		fprintf(stderr, "%s:pattern '%s'\n", buf, str);
		return 1;
	}
	return 0;
}
int socket_init(const char *ip, int port, struct sockaddr_in *serv_addr)
{
	int cfd;
	//struct sockaddr_in serv_addr;
	cfd = socket(AF_INET, SOCK_DGRAM, 0);	
	if (cfd == -1)
		err_sys("socket error");
	memset(serv_addr, 0, sizeof(*serv_addr));
	serv_addr->sin_family = AF_INET;
	serv_addr->sin_port = htons(port);
	inet_pton(cfd, ip, &serv_addr->sin_addr.s_addr);
	return cfd;
}
int main(int argc, char *argv[])
{
	int n, cfd, fd, flags = -1;// i;
	struct sockaddr_in serv_addr;
	struct stat st;
	char str[NR], *p = NULL, tot_name[MAXSIZE];
	char buf[MAXSIZE], *name;


	if (argc < 2) {
		printf("the argument is too less!\n");
		return EOF;
	}

	if (isdigit(argv[1][0])) {
		p = strstr(argv[1], ":");
		*p = '\0';
		flags = 0;
		//n = match_str(MATCH, argv[1]);
		cfd = socket_init(argv[1], SERV_PORT, &serv_addr);
		if (cfd == -1) {
			printf("socket_init error\n");
			exit(1);
		}
	}else {
		p = strstr(argv[2], ":");
		*p = '\0';
		flags = 1;
		//n = match_str(MATCH, argv[2]);
		cfd = socket_init(argv[2], SERV_PORT, &serv_addr);
		if (cfd == -1) {
			printf("socket_init error\n");
			exit(1);
		}
	}
#if 0
	cfd = socket(AF_INET, SOCK_DGRAM, 0);	
	if (cfd == -1)
		err_sys("socket error");
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERV_PORT);
	inet_pton(cfd, argv[1], (struct sockaddr *)&serv_addr.sin_addr.s_addr);
#endif
	if (flags == 0) {
		sprintf(str, "download %s %s", p +1, argv[2]);
		sendto(cfd, str, strlen(str), 0, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
		n = recvfrom(cfd, buf, MAXSIZE, 0, NULL, 0);
		if (strncmp(buf, "OK", 2) == 0) {
			name = &buf[3];
			printf("myscp name = %s\n", name);
			sprintf(tot_name, "%s/%s", argv[2], name);
			printf("tot_name = %s\n", tot_name);

			fd = open(tot_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
			if (fd == -1)
				err_sys("open error");
		}else if (strncmp(buf, "not_generalfile", n)) {
			printf("this file is not a general file\n");
			exit(1);
		}
		while ((n = recvfrom(cfd, buf, MAXSIZE, MSG_DONTWAIT, NULL, 0)) != -1)
			write(fd, buf, n);
	}else if (flags == 1){
		n = stat(argv[1], &st);
		if (S_ISREG(st.st_mode)) {
			sprintf(str, "copy %s %s", argv[1], p+1);
			printf("%s\n", str);
			sendto(cfd, str, strlen(str), 0, (struct sockaddr *)&serv_addr, sizeof(serv_addr));

			n = recvfrom(cfd, buf, MAXSIZE, 0, NULL, 0);
			buf[n] = '\0';
			if (strncmp(buf, "OK", 2) == 0)
				fd = open(argv[1], O_RDONLY | O_NONBLOCK);
			if (fd == -1)
				err_sys("open error");
			//i = 0;	
			while ((n = read(fd, buf, MAXSIZE)) != 0) {
				sendto(cfd, buf, n, 0, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
				//i++;
				//printf("line :%d\n", i);
			}
			sendto(cfd, "exit", 4, 0, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
		}else {
			printf("this is not a general file\n");
			exit(1);
		}
	}	

	close(fd);
	close(cfd);	
	return 0;
}
