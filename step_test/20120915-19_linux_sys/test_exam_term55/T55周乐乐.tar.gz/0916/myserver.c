#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>
#include <regex.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#define SERV_IP "127.0.0.1"
#define SERV_PORT 8000

#define N     5
#define MAXSIZE  1024

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

void get_char(char *str, char **ptr, int n)
{
	int i;
	char *tok = str;
	for (i = 0; i < n && (ptr[i++] = strtok(tok, " ")) != NULL; tok = NULL)
		printf("ptr[%d] = <%s>\n", i-1, ptr[i-1]);
}

int main(void)
{
	char buf[MAXSIZE], *tok[N], *name, str[20];
	struct sockaddr_in serv_addr, cli_addr;
	struct stat st;
	int sfd,  n, fd;
	socklen_t len = sizeof(cli_addr);

	sfd = socket(AF_INET, SOCK_DGRAM, 0);
	if (sfd == -1)
		err_sys("socket error");
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERV_PORT);
	inet_pton(sfd, SERV_IP, &serv_addr.sin_addr.s_addr);

	n = bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if (n == -1) 
		err_sys("bind error");
	while (1) {
		n = recvfrom(sfd, buf, MAXSIZE, 0, (struct sockaddr *)&cli_addr, &len);
		if (n == -1)
			continue;
		buf[n] = '\0';
		printf("buf = %s\n", buf);
		get_char(buf, tok, N);
		if (strcmp(tok[0], "download") == 0) {
			n = strlen(tok[1]);
			if (tok[1][n] == '/')	
				tok[1][n] = '\0';
			name = rindex(tok[1], '/')+1;
			printf("name = %s\n", name);
			fd = open(tok[1], O_RDONLY | O_NONBLOCK);
			if (fd == -1) {
				perror("open error");
				continue;
			}
			n = fstat(fd, &st);
			if (n == -1) {
				perror("fstat error");
				continue;
			}
			if (S_ISREG(st.st_mode)) {
				sprintf(str, "OK %s", name);
				n = sendto(sfd, str, strlen(str), 0, (struct sockaddr *)&cli_addr, len);
				while((n = read(fd, buf, MAXSIZE)) != 0)
					sendto(sfd, buf, n, 0, (struct sockaddr *)&cli_addr, len);
				close(fd);
			}else 
				sendto(sfd, "not_generalfile", strlen("not_generalfile"), 0, (struct sockaddr *)&cli_addr, len);

		}else if (strcmp(tok[0], "copy") == 0){
			n = strlen(tok[1]);
			if (tok[1][n] == '/')	
				tok[1][n] = '\0';
			name = rindex(tok[1], '/')+1;
			printf("name = %s\n", name);
			n = strlen(tok[2]);
			if (tok[2][n] == '/')
				sprintf(str, "%s%s", tok[2], name);
			else 
				sprintf(str, "%s/%s", tok[2], name);

			fd = open(str, O_WRONLY | O_CREAT | O_TRUNC | O_NONBLOCK, 0644);
			if (fd == -1) { perror("open error");
				continue;
			}
			//nsize = lseek(fd, 0, SEEK_END);
			sprintf(str, "OK %s", name);
			n = sendto(sfd, str, strlen(str), 0, (struct sockaddr *)&cli_addr, len);
			//while((n = recvfrom(sfd, buf, MAXSIZE, MSG_DONTWAIT, (struct sockaddr *)&cli_addr, &len)) != -1)
			while((n = recvfrom(sfd, buf, MAXSIZE, 0, (struct sockaddr *)&cli_addr, &len)) != -1)
			{
				if (strncmp(buf, "exit", 4) == 0)
					break;
				write(fd, buf, n);
			}
			close(fd);
		}
	}
	return 0;
}
