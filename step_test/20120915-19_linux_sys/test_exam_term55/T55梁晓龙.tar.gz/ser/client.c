#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_IP "127.0.0.1"
#define SERV_PORT 8000

int main(int argc, char *argv[])
{
	int sfd;
	char buf[1024], path[1024];
	int fd;
	char *token;
	struct sockaddr_in serv_addr;
	sfd = socket(AF_INET, SOCK_STREAM, 0);

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SETV_PORT);
	inet_pton(AF_INET, SERV_IP, &serv_addr.sin_addr.s_addr);

	connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));

	write(sfd, argv[1], strlen(argv[1]));
	sprintf(path, "%s/%s", argv[2], argv[1]);
		fd = open(path, O_WRONLY|O_CREAT|O_TRUNC, 0644);

	while(n = read(sfd, buf, 1024))
		write(fd, buf, n);
	close(sfd);
	return 0;


}
