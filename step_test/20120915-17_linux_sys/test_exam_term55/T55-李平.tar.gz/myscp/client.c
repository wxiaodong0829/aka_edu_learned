/*************************************************************************
  > File Name   : client.c
  > Function    : 
  > Author      : 李平
  > Mail        : 864081335@qq.com 
  > Created Time: 2012年09月15日 星期六 09时32分56秒
 ************************************************************************/
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<errno.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>

#define CONN 1/*发起连接*/
#define READ 2/*数据传输中*/
#define DONE 3/*数据传输完毕*/

struct myfile{
	char *filename;/*要下载的文件名*/
	int fd;/*本地文件描述符*/
	int cfd;/*传输数据所用的套接字文件描述符*/
	int status;/*文件状态四个*/
};

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

/* ./app 127.0.0.1:/home/lp/web/myweb.c . 格式*/
int main(int argc, char *argv[])
{
	int sfd, fd;
	struct sockaddr_in serv_addr;
	int n, i, flags, res;
	struct myfile list;
	char *dirname, *p, *q, *nbuf, *s;
	char buf[1024], path[1024];

	if(argc != 3)
		return 0;
	nbuf = argv[1];
	nbuf[strlen(argv[1])] = '\0';
	q = strstr(nbuf, ":");
	dirname = q + 1;
	p = rindex(nbuf, '/');

	list.filename = p + 1;
	list.fd = -1;
	list.cfd = -1;
	list.status = 0;

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd == -1)
		err_sys("socket error");
	list.cfd = sfd;

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(8000);
	inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr.s_addr);

	flags = fcntl(sfd, F_GETFL);
	flags |= O_NONBLOCK;
	fcntl(sfd, F_SETFL, flags);

	res = connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if(res == -1){/*连接失败*/
		if(errno != EINPROGRESS){/*EINPROGRESS是在非阻塞下连接失败时返回-1是的错误号*/
			perror("connect error");
			return -1;
		}
		list.status = CONN;
	}else if(res == 0){/*连接成功*/
		list.status = READ;

		flags = fcntl(sfd, F_GETFL);
		flags &= ~O_NONBLOCK;
		fcntl(sfd, F_SETFL, flags);

		write(sfd, argv[1], strlen(argv[1]));
		sprintf(path, "%s/%s", argv[2], list.filename);
		fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		list.fd = fd;
	}

	if(list.status == CONN){
		list.status = READ;

		flags = fcntl(sfd, F_GETFL);
		flags &= ~O_NONBLOCK;
		fcntl(sfd, F_SETFL, flags);

		write(sfd, argv[1], strlen(argv[1]));

		n = read(list.cfd, buf, 1024);
		if(strncmp(buf, "OK", 2) != 0){/*从服务器端下载数据*/
			printf("download tata to client...\n");
			sprintf(path, "%s/%s", argv[2], list.filename);
			fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
			list.fd = fd;
			write(list.fd, buf, n);
			while(n = read(list.cfd, buf, 1024)){
				if(n == 0){
					close(list.cfd);
					close(list.fd);
					list.status = DONE;
					printf("%s done...\n", list.filename);
					break;
				}else
					write(list.fd, buf, n);
			}
		}else{/*向服务器端上传数据*/
			printf("transfers data to server...\n");
			write(list.cfd, argv[2], strlen(argv[2]));
			read(list.cfd, buf, 1024);
			if(strncmp(buf, "yes", 3) != 0)
				return 0;
			fd = open(argv[1], O_RDONLY);
			if(fd == -1)
				err_sys("open error");
			while(n = read(fd, buf, 1024))
				write(sfd, buf, n);
		}
	}else if(list.status == READ){
		n = read(list.cfd, buf, 1024);
		if(n == 0){
			close(list.cfd);
			close(list.fd);
			list.status = DONE;
			printf("%s done...\n", list.filename);
		}else
			write(list.fd, buf, n);
	}

	printf("one round is over...\n");
	return 0;
}
