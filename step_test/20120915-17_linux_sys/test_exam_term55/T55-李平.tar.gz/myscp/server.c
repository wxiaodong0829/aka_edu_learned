/*************************************************************************
    > File Name   : server.c
    > Function    : 
    > Author      : 李平
    > Mail        : 864081335@qq.com 
    > Created Time: 2012年09月15日 星期六 09时33分07秒
 ************************************************************************/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define ROOT "/home/lt/lp/web"

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

int main(void) 
{
	int sfd, n, fd, lfd;
	struct sockaddr_in serv_addr;
	struct stat st;
	char *p, *q, *filename;
	pid_t pid;
	char buf[1024], path[1024];

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd == -1)
		err_sys("socket error");

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(8000);
	inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr.s_addr);

	n = bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if(n == -1)
		err_sys("bind error");

	n = listen(sfd, 20);
	if(n == -1)
		err_sys("listen error");

	while(1){
		lfd = accept(sfd, NULL, NULL);
		if(lfd == -1)
			err_sys("accept error");

		n = read(lfd, buf, 1024);
		buf[n] = '\0';

		stat(buf, &st);
		if(S_ISDIR(st.st_mode))
			return 0;
		if(strncmp(buf, "127", 3) == 0){/* 下载 */
			p = rindex(buf, '/');
			filename = p + 1;
			sprintf(path, "%s/%s", ROOT, filename);

			fd = open(path, O_RDONLY);
			if(fd == -1)
				err_sys("open error");

			while(n = read(fd, buf, 1024))
				write(lfd, buf, n);
			close(lfd);
		}else{/* 上传 */
			char str[256];
			char *route, *q;

			p = rindex(buf, '/');
			filename = p + 1;

			write(lfd, "OK", 2);

			n = read(lfd, str, 256);
			str[n] = '\0';
			q = strstr(str, ":");
			route = q + 1;
			if(str[n-1] == '/')
				sprintf(path, "%s%s", route, filename);
			sprintf(path, "%s/%s", route, filename);
			write(lfd, "yes", 3);

			fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
			while(n = read(lfd, buf, 1024)){
				if(n == 0){
					close(fd);
					close(lfd);
					printf("%s done...\n", filename);
					break;
				}else
					write(fd, buf, n);
			}

		}
	}
	close(sfd);
	return 0;
}
