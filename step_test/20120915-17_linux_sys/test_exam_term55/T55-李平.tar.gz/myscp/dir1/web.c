#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/socket.h>
#include<arpa/inet.h>

#define SERV_IP "127.0.0.1"
#define SERV_PORT 8000
#define ROOT "./www"/*文件所在的位置，是当前目录下的www內*/

#define REPLY_HEAD "HTTP/1.1 200 OK\r\nContent-Type:"
#define TEXT "text/html"
#define IMG "image/jpg"
#define REPLY_END "\r\n\r\n"

/* GET /filename HTTP/1.1 */

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}/*出错处理函数*/

int main(void)
{
	int lfd, cfd;
	struct sockaddr_in serv_addr;
	char buf[1024];
	int n;

	lfd = socket(AF_INET, SOCK_STREAM,0);/*创建套接字，用的是tcp协议*/
	if(lfd == -1)
		err_sys("socket error");

	memset(&serv_addr, 0, sizeof(serv_addr));/*对地址结构清零*/
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SERV_PORT);
	inet_pton(AF_INET, SERV_IP, &serv_addr.sin_addr.s_addr);/*初始化地址结构*/

	n = bind(lfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));/*绑定，把套接字和地址结构体合体，这样之后就固定了端口*/
	if(n == -1)
		err_sys("bind error");

	n = listen(lfd, 20);/*让套接字具有接受客户端的能力*/
	if(n == -1)
		err_sys("listen error");

	while(1){
		char path[1024]; 
		char *p, *q, *filename, *type;
		int fd;

		cfd = accept(lfd, NULL, NULL);/*返回新的套接字文件描述符，其用来与客户端进行数据通信*/
		if(cfd == -1)
			err_sys("accept error");

		n = read(cfd, buf, 1024);/*把从客户端传送过来的数据读到buf缓冲区当中*/
		buf[n] = '\0';/*对缓冲区内的内容加上\0，使其成为一个字符串*/
		printf("%s\n", buf);

		p = strstr(buf, " ");/*使p是第一个空格的地址*/
		q = strstr(p + 1, " ");/*使q指向第二个空格地址*/
		*q = '\0';/*把第二个空格置为\0这样就可以是filename是一个字符串*/
		filename = p + 2;/*得到文件的名字，p+2的原因是把原先的文件当中的/去掉，因为下面的拼接时能够更好的拼写*/
		printf("%s\n", filename);
		sprintf(path, "%s/%s", ROOT, filename);/*拼接path，使path指向的字符串是ROOT与filename拼接起来的,找到文件的绝对路径*/

		n = access(path, X_OK);/*access测试文件的权限，在这里我们测试的文件是否有执行的权限,返回0说明文件有这个权限，否则没有*/
		if(n == 0){/* cgi */
			pid_t pid;
			char *argv[2];

			write(cfd, REPLY_HEAD, strlen(REPLY_HEAD));
			write(cfd, TEXT, strlen(TEXT));
			write(cfd, REPLY_END, strlen(REPLY_END));/*在这个下面是说path文件是可执行文件，这三句是写入HTTP协议头*/

			pid = fork();/*创建子进程*/
			if(pid == 0){
				dup2(cfd, STDOUT_FILENO);/*标准输出的内容重定向给套接字，在这里写这个函数的原因是：exec系列的函数在调用完的时候之后所有的命令都不在执行，所以所有准备工作都应该在调用exec函数之前做完。这里的标准输出是shell.sh执行的结果*/
				argv[0] = path, argv[1] = NULL;
				execvp(path, argv);/*加载一个新的程序代替当前程序执行，这里的path是绝对路径，argv是新程序的命令行参数*/
				err_sys("exec error");
			}else{
				close(cfd);
				wait(NULL);/*父进程是用来对子进程进行收尸的，防止生成僵尸进程*/
			}
		}else{ p = rindex(filename, '.');/*得到文件名以后，判断文件名，看文件是什么类型的，，判断传输的数据是什么样的*/
			if(strcmp(p+1, "jpg") == 0)
				type = IMG;
			else
				type = TEXT;/*这个if语句是为了判断一下我们所得到的文件是什么类型的*/

			fd = open(path, O_RDONLY);/*以只读的的方式打开文件path*/
			if(fd != -1){
				write(cfd, REPLY_HEAD, strlen(REPLY_HEAD));
				write(cfd, type, strlen(type));
				write(cfd, REPLY_END, strlen(REPLY_END));/*三次都写到套接字发送的缓冲区內，这个缓冲区內大概能写入六万多的字节, 底层传出几次数据包与上层调用几次write函数没有关系*/

				while(n = read(fd, buf, 1024))
					write(cfd, buf, n);
				close(fd);
			}
			close(cfd);
		}
	}

	return 0;
}
