#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<ctype.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<sys/epoll.h>
#include<fcntl.h>
#include <sys/stat.h>


#define SERV_IP "127.0.0.1"
#define SERV_PORT 8080
#define BUF_SIZE 1024
#define PATH_SIZE 256
#define FD_MAX_NUM 1024
#define EVENT_MAX_NUM 1024
#define DOWN_LOAD '2'
#define UP_LOAD '1'

typedef struct jobs
{
	int src_fd;
	int dest_fd;
}jobs_t;

int analyse(char *buf, char *path, int *type);

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

int main(void)
{
	int n, type, nfds;
	int listenfd, connfd, epollfd;
	struct sockaddr_in serv_addr;
	char buf[BUF_SIZE], path[PATH_SIZE];
	struct epoll_event ev, events[EVENT_MAX_NUM];
	jobs_t jobs[FD_MAX_NUM];

	/* socket()*/
	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	if(listenfd == -1)
		err_sys("cocket");

	/* bind()*/
	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	inet_pton(AF_INET, SERV_IP, &serv_addr.sin_addr.s_addr);
	serv_addr.sin_port = htons(SERV_PORT);
	n = bind(listenfd, (const struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if(n == -1)
		err_sys("bind");

	/* listen()*/	
	n = listen(listenfd, 20);
	if(n == -1)
		err_sys("listen");

	/* epoll()*/	
	epollfd = epoll_create(EVENT_MAX_NUM);
	if (epollfd == -1)
		err_sys("epoll_creat");

	ev.events = EPOLLIN;
	ev.data.fd = listenfd;
	if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listenfd, &ev) == -1)
		err_sys("epoll_ctl: listen_sock");

	for(;;)//监听事件
	{
		nfds = epoll_wait(epollfd, events, EVENT_MAX_NUM, -1);//发生了nfds个事件
		if (nfds == -1)
			err_sys("epoll_pwait");

		for(n = 0; n < nfds; n++)
		{
			if(events[n].data.fd == listenfd)//监听套接字可读，即新链接到来
			{
				connfd = accept(listenfd, NULL, NULL);
				if(connfd == -1)
					err_sys("accept");

				ev.events = EPOLLIN;
				ev.data.fd = connfd;
				if (epoll_ctl(epollfd, EPOLL_CTL_ADD, ev.data.fd, &ev) == -1)
					err_sys("epoll_ctl: add");
			} 
			else//链接套接字事件
			{
				if(events[n].events == EPOLLIN)//接受请求
				{
					struct stat st;

					/*读取分析用户请求，根据请求设置传输方向（服务器的下载上传与用户相反）*/
					read(events[n].data.fd, buf, BUF_SIZE);
					analyse(buf, path, &type);
					stat(path, &st);
					if(S_ISDIR(st.st_mode))//目录文件不能传输
					{
						write(events[n].data.fd, "NO", 3);
						/*关闭请求监听*/
						epoll_ctl(epollfd, EPOLL_CTL_DEL, events[n].data.fd, NULL);
						ev.events = EPOLLOUT;
						ev.data.fd = events[n].data.fd;
					}
					else
					{
						if(type == UP_LOAD)
						{
							jobs[events[n].data.fd].src_fd = open(path, O_RDONLY);
							jobs[events[n].data.fd].dest_fd = events[n].data.fd;
						}
						else if(type == DOWN_LOAD)
						{
							jobs[events[n].data.fd].src_fd = events[n].data.fd;
							jobs[events[n].data.fd].dest_fd = open(path, O_RDWR | O_TRUNC | O_CREAT, 0664);
						}
						printf("get a %s %s\n", type =='2' ? \
								"upload request\nupload:" : "download request\ndownload:", path);

						/*准备就绪后向用户发出信息*/
						write(events[n].data.fd, "OK", 3);

						/*关闭请求监听，打开传输监听*/
						epoll_ctl(epollfd, EPOLL_CTL_DEL, events[n].data.fd, NULL);
						ev.events = EPOLLOUT;
						ev.data.fd = events[n].data.fd;
						epoll_ctl(epollfd, EPOLL_CTL_ADD, events[n].data.fd, &ev);
					}

				}
				else//开始传输
				{
					int num;
					num = read(jobs[events[n].data.fd].src_fd, buf, BUF_SIZE);

					if(num)
						write(jobs[events[n].data.fd].dest_fd, buf, num);
					else
					{
						if(epoll_ctl(epollfd, EPOLL_CTL_DEL, events[n].data.fd, NULL) == -1)
							err_sys("epoll_ctl: delete");
						close(jobs[events[n].data.fd].src_fd);
						close(jobs[events[n].data.fd].dest_fd);
					}
				}
			}
		}
	}

	/*正常情况服务器不会离开循环*/
	printf("you should not pass!\n");
	return 0;
}

int analyse(char *buf, char *path, int *type)
{
	*type = buf[0];
	strcpy(path, buf+1);
	return 0;
}
