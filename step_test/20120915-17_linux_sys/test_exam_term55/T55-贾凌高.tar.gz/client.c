#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<fcntl.h>
#include<sys/types.h>
#include<regex.h>

#define SERV_PORT 8080
#define DOWN_LOAD '1'
#define UP_LOAD '2'

typedef struct jobs
{
	char serv_ip[16];
	char serv_file_path[256];
	char local_file_path[256];
	char type;
}jobs_t;

void err_sys(const char *str)
{
	perror(str);
	exit(1);
}

int analyse(char *argv[],jobs_t *jobs);

int main(int argc, char *argv[])
{
	int sockfd, src_fd, dest_fd, n;
	struct sockaddr_in serv_addr;
	char buf[1024];
	jobs_t jobs;

	/*验证并解析用户输入*/
	if(argc < 3 || analyse(argv, &jobs) == -1)
	{
		printf("input err\n");
		exit(1);
	}

	printf("ip:%s\nserv_path:%s\nlocal_path:%s\ntype:%s\n", jobs.serv_ip, \
			jobs.serv_file_path, jobs.local_file_path, jobs.type =='2' ? "upload" : "download");

	/*建立套接字，链接服务器*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
		err_sys("sockfd");

	memset(&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	inet_pton(AF_INET, jobs.serv_ip, &serv_addr.sin_addr.s_addr);
	serv_addr.sin_port = htons(SERV_PORT);

	if(connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
	{
		printf("connect err\n");
		exit(1);
	}

	/*向服务器发出上传或下载请求，读取服务器应答*/
	sprintf(buf, "%c%s", jobs.type, jobs.serv_file_path);
	write(sockfd, buf, strlen(buf)+2);

	read(sockfd, buf, 3);
	if(strcmp(buf, "OK") == 0)
		;
	else if(strcmp(buf, "NO") == 0)
	{
		printf("server can not do this\n");
		exit(1);
	}

	/*得到服务器就绪应答，打开（建立）文件，开始传输*/
	if(jobs.type == DOWN_LOAD)
	{
		src_fd = sockfd;
		if((dest_fd = open(jobs.local_file_path, O_RDWR | O_TRUNC | O_CREAT, 0664)) == -1)
			err_sys("open");
	}
	else if(jobs.type == UP_LOAD)
	{
		if((src_fd = open(jobs.local_file_path, O_RDONLY)) == -1)
			err_sys("open");
		dest_fd = sockfd;
	}
	while((n = read(src_fd, buf, 1024)))
		write(dest_fd, buf, n);

	close(src_fd);
	close(dest_fd);

	return 0;
}

int analyse(char *argv[], jobs_t *jobs)
{
	char file_name[256];
	regex_t preg_ip, preg_file_name;
	regmatch_t pmatch;
	regcomp(&preg_ip, "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}", REG_EXTENDED);
	regcomp(&preg_file_name, "/[^/]+$", REG_EXTENDED);

	regexec(&preg_ip, argv[1], 1, &pmatch, 0);
	if(pmatch.rm_eo > pmatch.rm_so)//从服务器下载
	{
		/*提取ip*/
		strncpy(jobs->serv_ip, argv[1]+pmatch.rm_so, pmatch.rm_eo-pmatch.rm_so);
		jobs->serv_ip[pmatch.rm_eo-pmatch.rm_so] = '\0';

		/*提取服务器上文件路径*/
		strcpy(jobs->serv_file_path, argv[1]+pmatch.rm_eo+1);

		/*提取文件名*/
		regexec(&preg_file_name, jobs->serv_file_path, 1, &pmatch, 0);
		strcpy(file_name, jobs->serv_file_path+pmatch.rm_so);

		/*将文件名和本机目录拼成本机文件路径*/
		strcpy(jobs->local_file_path, argv[2]);
		strcat(jobs->local_file_path, "/");
		strcat(jobs->local_file_path, file_name);

		/*标记为下载模式*/
		jobs->type = DOWN_LOAD;

		regfree(&preg_ip);
		regfree(&preg_file_name);
		return 0;
	}

	regexec(&preg_ip, argv[2], 1, &pmatch, 0);
	if(pmatch.rm_eo > pmatch.rm_so)//向服务器上传
	{
		/*提取ip*/
		strncpy(jobs->serv_ip, argv[2]+pmatch.rm_so, pmatch.rm_eo-pmatch.rm_so);
		jobs->serv_ip[pmatch.rm_eo-pmatch.rm_so] = '\0';

		/*提取本机文件路径*/
		strcpy(jobs->local_file_path, argv[1]);
		strcpy(jobs->serv_file_path, argv[2]+pmatch.rm_eo+1);

		/*提取文件名*/
		regexec(&preg_file_name, jobs->local_file_path, 1, &pmatch, 0);
		strcpy(file_name, jobs->local_file_path+pmatch.rm_so);

		/*将文件名和服务器目录拼成服务器上文件路径*/		
		strcat(jobs->serv_file_path, "/");
		strcat(jobs->serv_file_path, file_name);

		/*标记为上传模式*/
		jobs->type = UP_LOAD;

		regfree(&preg_ip);
		regfree(&preg_file_name);
		return 0;
	}

	/*未发现任何服务器地址，输入错误，返回-1*/
	return -1;
}
