#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_PORT 8000
#define SERV_IP "127.0.0.1"

void err_sys(const char *str)
{
    perror(str);
    exit(1);
}

int main(void)
{
    int fd, lfd, cfd, n, i;
    socklen_t len;
    fd_set rest, wset, allset;
    struct sockaddr_in serv_addr, cli_addr;
    struct stat buf;
    char str[1024], path[1024], str_t[1024];

    lfd = socket(AF_INET, SOCK_STREAM, 0);
    if(lfd == -1)
        err_sys("socket error");

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERV_PORT);
    inet_pton(AF_INET, SERV_IP, &serv_addr.sin_addr.s_addr);

    n = bind(lfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    if(n == -1)
        err_sys("bind error");
    n = listen(lfd, 20);
    if(n == -1)
        err_sys("listen error");
    
    while(1) {
        len = sizeof(cli_addr);
        cfd = accept(lfd, (struct sockaddr *)&cli_addr, &len);
        if(cfd == -1)
            err_sys("accqept error");
        n = read(cfd, str, 1024);
        str[n] = '\0';
        stat(str, &buf);
        if(S_ISREG(buf.st_mode)) {
            fd = open(str, O_RDONLY);
            while(n = read(fd, str, 1024))
                write(cfd, str, n);
        }
        else if(S_ISDIR(buf.st_mode)) {
            n = read(cfd, str_t, 1024);
            str_t[n] = '\0';
            sprintf(path, "%s/%s", str, str_t);

            fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            while(n = read(cfd, str, 1024))
                write(fd, str, n);
        }
        close(fd);
        close(cfd);
    }
    return 0;
}
