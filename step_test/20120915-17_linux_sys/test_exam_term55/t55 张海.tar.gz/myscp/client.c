#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_IP "127.0.0.1"
#define SERV_PORT 8000

void err_sys(char *str)
{
    perror(str);
    exit(1);
}

int main(int argc, const char *argv[])
{
    int sfd, n, fd;
    struct sockaddr_in serv_addr;
    struct stat buf;
    char buf_file[1024], buf_dir[1024]; 
    char str[1024], path[1024];
    char *p;

    if(argc != 3) 
        err_sys("argc error");

    sfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sfd == -1)
        err_sys("socket error");

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(SERV_PORT);
    inet_pton(AF_INET, SERV_IP, &serv_addr.sin_addr.s_addr);

    n = connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    if(n == -1)
        err_sys("connect error");

    if(p = strstr(argv[1], ":")) {
        strcpy(buf_file, p + 1);
        stat(buf_file, &buf);
        if(S_ISREG(buf.st_mode)) {
            if(p = strstr(argv[2], ":")) 
                err_sys("input dir1 error");
            strcpy(buf_dir, argv[2]);
            stat(buf_dir, &buf);
            if(S_ISDIR(buf.st_mode))
                p = rindex(buf_file, '/');
                sprintf(path, "%s/%s", buf_dir, p + 1);
                write(sfd, buf_file, strlen(buf_file));
                fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
                while(n = read(sfd, str, 1024))
                    write(fd, str, n);
                close(fd);
                close(sfd);
        }else
                err_sys("input file error");
    }else{
        strcpy(buf_file, argv[1]);
        stat(buf_file, &buf);
        if(S_ISREG(buf.st_mode)) {
            if(p = strstr(argv[2], ":")) {
                strcpy(buf_dir, p + 1);
                stat(buf_dir, &buf);
                if(S_ISDIR(buf.st_mode)) {
                    write(sfd, buf_dir, 1024);
                    p = rindex(buf_file, '/');
                    write(sfd, p + 1, 1024);
                    fd = open(buf_file, O_RDONLY);
                    while(n = read(fd, str, 1024))
                        write(sfd, str, n);
                    close(fd);
                    close(sfd);
                }
            }else
                    err_sys("input dir error");
        } else
            err_sys("input file error");
    }
    return 0;
}
