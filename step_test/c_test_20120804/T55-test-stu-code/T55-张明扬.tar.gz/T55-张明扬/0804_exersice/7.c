#include <stdio.h>

struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
}
