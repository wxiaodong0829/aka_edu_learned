#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int arr[5][5];

void init()
{
	int i, j;
	srand(time(NULL));
	for(i=0; i<5; i++)
		for(j=0; j<5; j++)
			arr[i][j] = rand()%100;
}

void show()
{
	int i ,j;

	for(i=0; i<5; i++)
	{
		for(j=0; j<5; j++)
			printf("%3d", arr[i][j]) ;
		printf("\n");
	}
	printf("\n");
}

#if 0
void sort()
{
	int i, j, k, tmp, min;

	for(k=0; k<5; k++){
		for(i=0; i<4; i++)
		{
			min = i;
			for(j=i+1; j<5; j++)
			{
				if(arr[k][min] > arr[k][j]){
					min = j;}
			}
			if(min != i){
				tmp = arr[k][min];
				arr[k][min] = arr[k][i];
				arr[k][i] = tmp;
			}
		}
	}
	show();
}
#endif

void sort()
{
	int i, j, k, tmp, min;

	for()

	show();
}

int main(void)
{

	init();
	show();
	printf("________________________________\n");
	sort();

	return 0;
}
