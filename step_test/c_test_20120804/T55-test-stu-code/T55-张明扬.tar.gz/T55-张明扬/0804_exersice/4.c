#include <stdio.h>
#include <string.h>

#define N 100
char str[N];

int main(void)
{
	int i, max;
	char tmp;

	scanf("%s", str);
	printf("%s\n", str);	

	max = strlen(str) -1;
	for(i=strlen(str)-2; i>=0; i--){
		if(str[max] < str[i])  
			max = i;
		}
	tmp = str[max];
	for(; max > 0; max-- )
		str[max] = str[max-1];
	str[0] = tmp;

	printf("%s\n", str);

}
