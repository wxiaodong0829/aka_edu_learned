#include <stdio.h>

#define N 10

char *myitoa(int n, char *p)
{
	int i, j, flag;
	char tmp;
	i = 0;
	
	if((flag=n)<0) n = -n;

	do{
		p[i++] = n%10 + '0';
	}while(n /= 10);
	if(flag < 0) p[i++] = '-';
	p[i] = '\0';

	for(--i, j=0; j<=i; i--, j++){
		tmp = p[j];
		p[j] = p[i];
		p[i] = tmp;
	}

	return p;
}

int main(void)
{
	int n;
	char str[N];

	scanf("%d", &n);

	printf("str= %s\n", myitoa(n, str));

	return 0;
}
