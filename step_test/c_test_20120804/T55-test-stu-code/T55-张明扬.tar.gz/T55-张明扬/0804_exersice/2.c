#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int num[10];

void init(int l, int r)
{
	int i;
	srand(time(NULL));
	for(i=l; i<r; i++)
		num[i] = rand()%100;
}


void show(int l, int r)
{
	int i;
	for(i=l; i<r; i++)
		printf("%3d", num[i]);
	printf("\n");
}

#if 0
//冒泡排序部分
void bub_sort(int l, int r)
{
	int i, j, flag;
	int tmp;
	
	for(i=l; i<r-1; i++)
	{
		flag = 1;
		for(j=0; j<r-1; j++)
			if(num[j] > num[j+1]) 
			{
				flag = 0;
				tmp = num[j];
				num[j] = num[j+1];
				num[j+1] = tmp;
			}
		if(flag)  break;
	}
	show(0, 10);

}
#endif

void sort(int l, int r)
{
	int i, j, tmp;
	int min;
	
	for(i=0; i<r-1; i++)
	{
		min = i;
		for(j=i+1; j<r; j++)
		{
			if(num[min] > num[j]){
				min = j;}
		}
		if(min != i){
			tmp = num[min];
			num[min] = num[i];
			num[i] = tmp;
			}
	}

	show(0, 10);
}

int main(void)
{
	init(0, 10);
	show(0, 10);
	printf("----------------------------------\n");
//	bub_sort(0, 10);
	printf("----------------------------------\n");
	sort(0, 10);
	return 0;
}
