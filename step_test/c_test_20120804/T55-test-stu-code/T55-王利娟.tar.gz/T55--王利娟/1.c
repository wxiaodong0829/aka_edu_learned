#include <stdio.h>

void factorial(int n)
{
	int i,j;
	int count = 1;

	printf("2 ");
	for(i=3; i<=n; i++)
	{
		for(j=2; j*j<i; j++)
			if(i%j == 0)
				break;
		if(j*j > i)
		{
			printf("%d ",i);

			count++;
			if(count%10 == 0)
				printf("\n");
		}
	}
}

int main()
{
	int n;

	scanf("%d",&n);
	factorial(n);
	printf("\n");
	return 0;
}
