#include <string.h>
#include <stdio.h>

void reverse(char *str)
{
	int l=0,r=strlen(str)-1;
	char tmp;
	for(; l<=r;l++,r--)
		tmp = str[l], str[l] = str[r], str[r] = tmp;
}
char *myitoa(int n, char *str)
{
	int i=0;
	int sign;
	if((sign=n)<0)
		n=-n;
	do
	{
		str[i++] = n%10 + '0';
	}while((n/=10)>0);
	if(sign<0)
		str[i++]='-';
	str[i] = '\0';
	reverse(str);
	return str;
}

int main()
{
	int n = 34;
	char str[10];
	printf("n=%s\n",myitoa(n,str));
	return 0;
}
