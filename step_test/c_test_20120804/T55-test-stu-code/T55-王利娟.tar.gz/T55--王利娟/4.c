#include <stdio.h>

int maxchar(char *str, int l, int r)
{
	int i,k;
	char max=str[l];
	for(i=l+1; i<r; i++)
		if(max < str[i])
		{
			max = str[i];
			k = i;
		}
	for(i=k-1; i>=0; i--)
	{
		str[k--]=str[i];
	}
	str[0]=max;

	return 0;
}

int main()
{
	int k;
	char tmp;
	char str[6] = "chyab";	
	k = maxchar(str, 0, 5);
	printf("%s\n",str);
}

