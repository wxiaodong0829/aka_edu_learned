#include <stdio.h>
#include <time.h>

int num[10];

void init_num()
{
	int i;

	srand(time(NULL));
	for(i=0; i<10; i++)
		num[i] = rand()%100;
}

void swap(int i, int j)
{
	int tmp;
	tmp = num[i];
	num[i] = num[j];
	num[j] = tmp;
}

void sort1(int l, int r)
{
	int i,j;
	int flag =1;
	for(i=l; i<r && flag==1; i++)
	{
		flag =0;
		for(j=i+1; j<=r;j++)
			if(num[i] > num[j])
			{
				swap(i,j);
				flag = 1;
			}

	}
}
void sort2(int l, int r)
{
	int i,j,k;
	for(i=0; i<r; i++)
	{
		k=i;
		for(j=i+1; j<=r; j++)
		{
			if(num[j] < num[k])
				k=j;
		}
		if(k!=i)
			swap(k,i);
	}
}

int main()
{
	int i;

	init_num();

	for(i=0; i<10; i++)
		printf("%d ",num[i]);
	printf("\n");
	sort1(0,9);
	for(i=0; i<10; i++)
		printf("%d ",num[i]);
	printf("\n");
	sort2(0,9);
	for(i=0; i<10; i++)
		printf("%d ",num[i]);
	sort2(0,9);
	printf("\n");

	
	return 0;
}
