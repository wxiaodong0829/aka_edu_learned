#include <stdio.h>
#include <stdlib.h>
int  fun(void *a, void *b, void *c)
{
	switch(*(char *)c)
	{
		case '+':
			return *(int *)a+*(int *)b;
		case '-':
			return *(int *)a-*(int *)b;
		case '*':
			return *(int *)a * *(int *)b;
		case '/':
			return *(int *)a / *(int *)b;
		case '#': exit(0);
	}
}
int main()
{
	int a=3, b=4;
	char c='+';
	int sum;

	 int  (*f)(void *,void *, void *) = fun;
	 sum = f(&a,&b,&c);
	printf("%d\n",sum);
	return 0;
}
