#include <stdio.h>
#include <time.h>

int arr[5][5];

void init_arr()
{
	int i,j;

	srand(time(NULL));
	for(i=0; i<5; i++)
		for(j=0;j<5;j++)
		arr[i][j] = rand()%100;
}

void swap(int i, int j, int  (*pa)[5])
{
	int tmp;
	tmp = *(*pa+i);
	*(*pa+i) = *(*pa+j);
	*(*pa+j) = tmp;
}

void sort(int l, int r, int (*pa)[5])
{
	int i,j,k;
	for(i=0; i<r; i++)
	{
		k=i;
		for(j=i+1; j<=r; j++)
		{
			if(*(*pa+j) < *(*pa+k))
				k=j;
		}
		if(k!=i)
			swap(k,i,pa);
	}
}

int main()
{
	int i, j;

	init_arr();

	for(i=0; i<5; i++)
	{
		for(j=0;j<5;j++)
		printf("%d ",arr[i][j]);
		printf("\n");

		sort(0,4, &arr[i]);
		for(j=0; j<5; j++)
		printf("%d ",arr[i][j]);
		printf("\n\n");
	}
	printf("************************************\n");
	sort(0,24,arr);
		for(i=0; i<5; i++)
			for(j=0; j<5; j++)
				printf("%d ",arr[i][j]);
	printf("\n");
	
	printf("\n");

	
	return 0;
}
