#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
char  *vstrcat(const char *first,...)
{
	va_list ap;
	char *p, *q,*pt;
	int i;

	int len = strlen(first);
	q=p = malloc((len+1) * sizeof(char));
	strcpy(q,first);
	va_start(ap,first);	
	printf("%s\n",q);

	while((pt = va_arg(ap, char *))!=NULL)
	{
		p = p+len;
		len = strlen(pt);
		p = malloc((len+1) * sizeof(char));
		strcat(q,pt);
		printf("%s\n", q);
	}
	va_end(ap);
	return p;
}

int main()
{
	char first[] = "qwer";
	char second[] = "asdf";
	char three[] = "zxcv";
	char *p;
	p = vstrcat(first, second, three, (char *)NULL);
	return 0;
}

