#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
    char src[20], tmp;
    int i, j, finial;

    printf("Input a src:");
    scanf("%s", src);

    for(i = finial = strlen(src) - 1; i >= 0; i--){
        if(isdigit(src[i])){
            tmp = src[i];
            for(j = i; i < finial; i++)
                src[i] = src[i + 1];

            src[finial--] = tmp;
        }
    }
    printf("output src:%s\n", src);
    return 0;
}
