#include <stdio.h>
#include <string.h>

void reverse(char *str)
{
	int l=0,r=strlen(str)-1;
	char tmp;
	for(; l<=r;l++,r--)
		tmp = str[l], str[l] = str[r], str[r] = tmp;
}
void dollars(char *dest, char const *src)
{
	int i, j=0;
	int len = strlen(src);
	int count = 0;
	if(len == 0)
		return;
	else if(len == 1)
	{
		dest[0] = '0';
		dest[1] = '.';
		dest[2] = '0';
		dest[3] = src[0];
		dest[4] = src[1];
	}
	else if(len == 2)
	{
		dest[0] = '0';
		dest[1] = '.';
		dest[2] = src[0];
		dest[3] = src[1];
		dest[4] = src[2];
	}
	else
	{
		dest[j++] = src[len-1];	
		dest[j++] = src[len-2];	
		dest[j++] = '.';
		for(i=len-3;i>=0;i--)
		{
			count ++;
			if(count % 3 !=0)
				dest[j++] = src[i];
			if(count % 3 == 0&&i!=0 )
			{
				dest[j++]=src[i];
				dest[j++]=',';
			}
			if(count % 3 == 0 && i==0 )
				dest[j++]=src[i];
		}
		dest[j]='\0';
		printf("%s\n",dest);
		reverse(dest);
	}
}

int main(int argc, char *argv[])
{
	char dest[10];
	if(argc != 2)
	{
		printf("argument too duo or few\n");
		return 0;
	}
	dollars(dest,argv[1]);
	printf("$%s\n",dest);
	
	return 0;
}
