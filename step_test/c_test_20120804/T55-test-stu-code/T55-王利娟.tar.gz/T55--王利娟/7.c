#include <stdio.h>
typedef struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
}Stu;

void readrec(Stu *stu)
{
	int i;
	int n;
	
	printf("Input 10 students information:\n");
	for(i=0; i<10; i++)
	{
		scanf("%d %s %d %d %d %d",&stu[i].id,stu[i].name,&stu[i].s[0],&stu[i].s[1],&stu[i].s[2],&stu[i].s[3]);
		stu[i].ave=(stu[i].s[0]+stu[i].s[1]+stu[i].s[2]+stu[i].s[3])/4;
	}
}
void writerec(Stu *stu)
{
	int i;
	printf("output 10 students information\n");
	for(i=0; i<10; i++)
		printf("%d\t%s\t%d %d %d %d %.3f\n",stu[i].id,stu[i].name,stu[i].s[0],stu[i].s[1],stu[i].s[2],stu[i].s[3],stu[i].ave);

}

int main()
{
	Stu stu[10];
	readrec(stu);
	writerec(stu);
	
	return 0;
}




