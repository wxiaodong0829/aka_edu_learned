#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define N 20
char s[N];
char swap(char s[])
{
	int i,j;
	char tem;
	for(i=0,j=strlen(s)-1;i<j;i++,j--) {
		tem=s[i];
		s[i]=s[j];
		s[j]=tem;}
}
char *myitoa(int n,char *p)
{
	int i,j,flag;
	i=0;
	if((flag=n)<0) n=-n;
	do{
		p[i++]=n%10+'0';
	}while(n=n/10);
	if(flag<0){ p[i++]='-';}
	p[i]='\0';
	swap(s);
	return p;
	printf("\n");
}
int main(void)
{
//	char *p=s;
	//myitoa(123,p);
	printf("%s\n",myitoa(970,s));
	return 0;
}
