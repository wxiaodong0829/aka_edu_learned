#include<stdio.h>
#include<string.h>
#include<ctype.h>
void fun(char s[])
{
	int i,j,end;
	char tem;
	for(i=end=strlen(s)-1;i>0;i--){
		if(isdigit(s[i])){
			tem=s[i];
			for(j=i;i<end;i++)
				s[i]=s[i+1];
			s[end--]=tem;
		}
	}
	printf("%s\n",s);
}
int main(void)
{
	char a[]="asd123fhg345";
	fun(a);
	return 0;

}

