#include<stdio.h>
#include<time.h>
#define N 5
int arr[5][5];
int init(char arr[],int n)
{
	int i,j;
	srand(time(NULL));
	for(i=0;i<5;i++){
		for(j=0;arr[i][j];j++)
			arr[i][j]=rand()%100;
}
int show(int i,int j)
{
	for(i=0;i<N;i++)
		for(j=0;arr[i][j];j++)
			printf("%2d",arr[i][j]);
}
void swap(int l,int r)
int main(void)
{

	init(arr);
	show(0,N-1);
	printf("-------\n");
	/*for(i=0;i<5;i++)
		arr[0][i]=a[i];
	for(j=0;arr[i][j];j++);
	printf("%2d",arr[i][j]);
*/	

	return 0;
}

