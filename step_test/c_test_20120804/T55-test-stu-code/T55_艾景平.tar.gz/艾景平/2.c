#include<stdio.h>
#include<time.h>
#define N 10
int num[N];
int init(int l,int r)
{
	int i;
	srand(time(NULL));
	for(i=0;i<N;i++){
		num[i]=rand()%100;
		printf("%3d",num[i]);
	}
	printf("\n");
}
void show(int l, int r)
{
	int i;
	for (i=0; i<l; i++) printf("   ");
	for (i=l; i<=r; i++) printf("%3d", num[i]);
	printf("\n");
}
int swap(int i,int j)
{
	int tem;
	tem=num[i];
	num[i]=num[j];
	num[j]=tem;
}
int partition(int l, int r)
{
	int i, j;
	int k = rand()%(r-l+1) + l;
	swap(l, k);
	for (j=l, i=j+1; i<=r; i++) if (num[i]<num[l]) swap(i, ++j);
	swap(l, j);
	return j;
}
void sort(int l, int r)
{
	if (l>=r) return;
	int k = partition(l, r);
	sort(l, k-1);
	sort(k+1, r);
}
int main(void)
{
	init(0,N-1);
	sort(0,N-1);
	show(0,N-1);
	return 0;
}
