#include<stdio.h>
int primes(int n)
{

	int i,j,flag;
	if(i=2)
		printf("   2");
	for(i=3;i<=n;i=i+2)
	{
		flag=1;
		for(j=3;j*j<=i;j++){
			if(i%j==0) flag=0;continue;
		}
	if(flag==1)
		printf("%3d",i);
	}
	printf("\n");

}
int main(void)
{
	int n;
	printf("please input n:\n");
	scanf("%d",&n);
	primes(n);
	return 0;

}
