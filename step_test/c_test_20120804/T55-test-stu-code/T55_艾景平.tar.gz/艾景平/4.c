#include<stdio.h>
#include<string.h>	
char max(char str[])
{
	int i,j;
	char max;
	max=str[7];
	for(i=6;i>0;i--)
	{
		if(max<str[i]){
			max=str[i];
			for(i=j;i<7;i--)
				str[i]=str[i-1];
		}
		str[0]=max;
		printf("%s\n",str);
	}
	printf("\n");
}
int main(void)
{
	char str[7]="abcdef";
	max(str);
	return 0;
}
