#include<stdio.h>
#include<time.h>
int init_arr(int s[], int n)
{
	int i;

	srand(time(NULL));

	for(i = 0; i < n; i++)
		s[i] = rand() % 100;
}

int print_arr(int s[], int n)
{
	int i;

	for(i = 0; i < n; i++)
		printf("%3d", s[i]);

	printf("\n");
}

int bub_sort(int s[], int n)
{
	int i, j, tmp;
	int flag;

	for(i = 0; i < n-1; i++)
	{
		flag = 0;
		for(j = n - 2; j >= i; j--)
			if(s[j + 1] < s[j])
			{
				tmp = s[j + 1];
				s[j + 1] = s[j];
				s[j] = tmp;
				flag = 1;
			}
			if(!flag)
				return ;
	}
}

int sel_sort(int s[], int n)
{
	int i, j, k, tmp;

	for(i = 0; i < n - 1; i++)
	{
		k = i;
		for(j = i + 1; j < n; j++)
		{
			if(s[j] < s[k])
				k = j;
		}
		if(k != i)
		{
			tmp = s[i];
			s[i] = s[k];
			s[k] = tmp;
			
		}
	}

}

int main()
{
	int num[10];
	int m;

	printf("before...\n");
	init_arr(num, 10);
	print_arr(num, 10);

	printf("please choose...(1. bubble sort 2. selection sort): ");
	scanf("%d", &m);
	
	switch (m) {
		case 1: 
			printf("after...\n");
			bub_sort(num, 10);
			print_arr(num, 10);
			break;
		case 2:
			printf("after...\n");
			sel_sort(num, 10);
			print_arr(num, 10);
			break;
		defult : 
			break;
	}

	return 0;
}
