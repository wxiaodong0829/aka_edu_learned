#include<stdio.h>

void prime(int n)
{
	int i, j;

	for(i = 2; i <= n; i++)
	{
		for(j = 2; j*j < i; j++)
			if (i % j == 0)
				break;
		if(j*j>i)
			printf("%4d", i);
	}
}

int main(void)
{
	int num;
	int i;

	scanf("%d", &num);

	prime(num);

	printf("\n");

	return 0;
}
