#include<stdio.h>
#include<string.h>
#define MAX	100

void myitoa(int n, char s[])
{
	
	int i, j, len, c;
	i = 0;

	do {
		s[i++] = n % 10 + '0';
	} while((n /= 10) > 0);
	s[i] = '\0';

	for(i = 0, j = strlen(s)-1; i < j; i++, j--)
	{
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}

	for(i = 0; i < strlen(s); i++)
		printf("%c", s[i]);
}

int main(void)
{
	int num;
	char str[MAX];

	scanf("%d", &num);

	myitoa(num, str);
	
	printf("\n");

	return 0;
}
