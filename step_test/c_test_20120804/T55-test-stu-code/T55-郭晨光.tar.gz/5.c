#include<stdio.h>
#include<string.h>
#define MAX 100

char *fun(char *s, int n)
{
	int i, j, end;
	char tmp;

	for(end = i = n - 1; i >= 0; i--) 
	{
		if(s[i] >= '0' && s[i] <= '9') {
			tmp = s[i];

			for(j = i + 1; j <= end; j++)
				s[j - 1] = s[j];
			s[end--] = tmp;
		}
	}

	return s;
}

int main(void)
{
	char str[MAX];
	int len;

	printf("please input a string:");
	scanf("%s", str);

	len = strlen(str);

	fun(str, len);

	printf("%s\n", str);

	return 0;
}
