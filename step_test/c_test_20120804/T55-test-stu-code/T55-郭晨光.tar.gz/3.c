#include<stdio.h>
#include<time.h>

int init_arr(int (*s)[5], int m, int n)
{
	int i, j;

	srand(time(NULL));

	for(i = 0; i < m; i ++)
		for(j = 0; j < n; j++)
			s[i][j] = rand() % 100;
}

int print_arr(int (*s)[5], int m, int n)
{
	int i, j;

	for(i = 0; i < m; i++)
	{
		for(j = 0; j < n; j++)
			printf("%4d", s[i][j]);
		printf("\n");
	}
}

int sel_sort(int s[], int n)
{
	int i, j, k, tmp;

	for(i = 0; i < n - 1; i++)
	{
		k = i;

		for(j = i + 1; j < n; j++)
		{
			if(s[j] < s[k])
				k = j;
		}
		if(k != i)
		{
			tmp = s[i];
			s[i] = s[k];
			s[k] = tmp;
			
		}
	}
}

int main()
{
	int i, j;
	int arr[5][5];
	init_arr(arr, 5, 5);
	print_arr(arr, 5, 5);

	printf("............................\n");

	for(i = 0; i < 5; i++)
	sel_sort(arr[i], 5);
	print_arr(arr, 5, 5);

	printf("............................\n");

	sel_sort(arr[0], 25);
	print_arr(arr, 5, 5);
	
	return 0;
}

