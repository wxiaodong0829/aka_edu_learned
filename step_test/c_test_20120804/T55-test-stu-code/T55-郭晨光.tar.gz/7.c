#include<stdio.h>
#include<string.h>
#define N	10

typedef struct stud {
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
}STU;

void readrec(STU arr[], int n)
{
	int i, j;
	int sum;
	printf("id  name  s[1~4] \n");

	for(i = 0; i < n; i++)
	{
		scanf("%hu %s %d %d %d %d", &arr[i].id, arr[i].name, &arr[i].s[0], &arr[i].s[1], &arr[i].s[2], &arr[i].s[3]);
		for(j = 0; j < 4; j++)
		{
			sum += arr[i].s[j];
			arr[i].ave = (double)sum / 4;
		}
	}
}

void writerec(STU arr[], int n) 
{
	int i;
	for(i = 0; i < n; i++)
		printf("%hu %s %d %d %d %d", arr[i].id, arr[i].name, arr[i].s[0], arr[i].s[1], arr[i].s[2], arr[i].s[3], arr[i].ave);
}
	
int main()
{
	STU student[N];

	readrec(student, N);

	writerec(student, N);

	printf("\n");
	
	return 0;
}
	

