#include<stdio.h>
#define	MAX 100
int main(void)
{
	char str[MAX];
	char max;
	int flag;
	int i;

	scanf("%s", str);

	max = str[0];

	for(i = 1; str[i] != 0; i++)
	{
		if(max < str[i])
			max = str[i];
				flag = i;
	}

	for(i = flag; i > 0; i--)
	{
		str[i] = str[i - 1];
	}

	str[0] = max;

	printf("%s\n", str);

	return 0;
	
}
