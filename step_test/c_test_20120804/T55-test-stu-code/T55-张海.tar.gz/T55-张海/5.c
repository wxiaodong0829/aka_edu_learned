#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{	
	char s[] = "asd123fgh543df";
	char tmp;
	int i, j, r;
	r = strlen(s) - 1;

	for (i = r; i >= 0; i--) {
		if (isdigit(s[i])) {

		 tmp = s[i];
		for(j = i + 1; j <= r; j++) 
			s[j-1] = s[j];
		
		s[r--] = tmp;
		}
	}
	
	printf("%s\n", s);
	return 0;
}
