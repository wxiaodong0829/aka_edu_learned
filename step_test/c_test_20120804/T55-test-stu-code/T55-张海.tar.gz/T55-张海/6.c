#include <stdio.h>
#include <string.h>
void reverse(char s[])
{
        char tmp;
        int i, j;
	for (i = 0, j = strlen(s) - 1; i <= j; i++, j-- ) {
		tmp = s[i]; s[i] = s[j]; s[j] = tmp;
	}
}
void myitoa(int a, char s[])
{
	int i, sign;

	sign = a;
	if(sign < 0)
		a = -a;
	i = 0;
	do{
		s[i++] = a % 10 + '0';
	}while((a /= 10) > 0 );
	if (sign < 0)
		s[i++] = '-';
	s[i] = '\0';
	reverse(s);
}
int main(void)
{
	char s[100];
	int i =-1234;
	myitoa(i, s);
	printf("%s\n", s);
	return 0;
}
