#include <stdio.h>
void sort(char s[])
{
	int i, j, sign;
	char max, tmp;
	max = s[0];
	for (i = 0; s[i] != '\0'; i++) {
		if (max < s[i]) {
		max = s[i];
		sign = i;
		}
	}
	printf("%c %d\n", max, sign);
	tmp = max;
	for (j = sign; j >= 1; j--) 
		s[j] = s[j-1];
	
	s[0] = tmp;
}
int main(void)
{
	char s[] = "chyab";
	sort (s);

	printf("%s\n", s);
	return 0;
}
