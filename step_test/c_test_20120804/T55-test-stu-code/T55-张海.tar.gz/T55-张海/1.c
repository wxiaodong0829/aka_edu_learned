#include <stdio.h>
int main(void)
{
	int n, i, j;
	printf("Please enter a number:");
	scanf("%d", &n);
	
	for (i = 1; i <= n; i++) {
		for (j = 2; j < i; j++) {

			if (i % j == 0)
				break;
		}

		if (i == j)
				printf("%4d", i);

	}
		printf("\n");
	return 0;
}
