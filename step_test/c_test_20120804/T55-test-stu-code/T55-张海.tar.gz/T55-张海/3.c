#include <stdio.h>
#include <time.h>
#define N 5
void swap(int s[], int i, int j)
{
	int tmp;
	tmp = s[i]; s[i] =s[j]; s[j] =tmp;
}
void choose(s[])
{
	int i, j, sign;
	for (i = 0; i < N; i++) {
		sign = i;
		for(j = i + 1; j < n; j++) {
			if (s[i] < s[sign])
				sign = j;
		}
		swap(s, i, sign);
	}
}
int main(void)
{
	int arr[5][5], i, j;
	srand(time(NULL));
	for (i = 0; i < N; i++) {
		for (j = 0; j < N ; j++) {
		arr[i][j] = rand()%100;




		
		return 0;
}
