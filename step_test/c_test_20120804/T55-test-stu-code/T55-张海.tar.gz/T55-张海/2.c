#include <stdio.h>
#include <time.h>
#define N 10
void swap(int s[], int i, int j)
{
	int tmp;
	tmp = s[i]; s[i] =s[j]; s[j] = tmp;
}
#if 0
void sort(int s[])
{
	int i, j;
	for (i = 0; i < N; i++) {
		for (j = 0; j < N-1; j++) {
			if (s[j] > s[j+1])
			swap (s, j, j+1);
		}
	}
}
#endif
void choose(int s[])
{
	int i, j, sign;
	for (i = 0; i < N; i++ ) {
		sign = i;
		for (j =i+1; j < N; j++) {
			if(s[j] < s[sign])
				sign = j;
		}
		swap(s, i, sign);
	}
}
int main(void)
{
	int num[N], i, j;
	srand(time(NULL));
	for (i= 0; i < N; i++) {
		num[i] = rand()%50;
		printf("%4d", num[i]);
	}
	printf("\n");
	//	sort (num);
		choose(num);
	for (j = 0; j < N; j++)
		printf("%4d", num[j]);
	printf("\n");

		return 0;
	
}
