/*************************************************************************
    > File Name   : readrec.c
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 14:28:38 2012
 ************************************************************************/

#include<stdio.h>

int readrec()
{
	struct stud arr[10][4];
	struct stud name[10];
    struct stud s[4];
	struct stud ave;
}
