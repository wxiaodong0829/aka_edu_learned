/*************************************************************************
    > File Name   : head.h
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 17:31:21 2012
 ************************************************************************/
#ifdef HEAD_H
#define HEAD_H

extern void readrec();
extern void writerec();


#endif
