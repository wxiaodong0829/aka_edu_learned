/*************************************************************************
    > File Name   : main.c
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 14:27:32 2012
 ************************************************************************/

#include<stdio.h>
struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double are;
};
int main(void)
{
	readrec();
	writerec();
	return 0;
}
