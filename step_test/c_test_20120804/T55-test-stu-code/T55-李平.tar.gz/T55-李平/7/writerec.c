/*************************************************************************
    > File Name   : writerec.c
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 17:29:18 2012
 ************************************************************************/

#include"head.h"

void writerec()
{
	printf("%d\t%s\t%d",id,name,s);
}

