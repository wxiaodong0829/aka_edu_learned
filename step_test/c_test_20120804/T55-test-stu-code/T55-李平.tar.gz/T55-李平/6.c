/*************************************************************************
    > File Name   : 6.c
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 14:10:33 2012
 ************************************************************************/

#include<stdio.h>

char *myitoa(int n, char *p)
{
	int sign;
	int i, j;
	char tmp;
	char *table = "0123456789";

	if((sign = n) < 0)
		n = -n;
	i = 0;
    do{
	p[i++] = table[n % 10];
	}while((n /= 10) > 0);
	if (sign < 0)
    p[i++] = '-';
	p[i] = '\0';

	for(--i,j=0;j<i;i--,j++)
		tmp=p[j],p[j]=p[i],p[i]=tmp;
	return p;
}

int main(void)
{
	int n;
	char p[20];

	printf("Input n:");
		scanf("%d", &n);

	printf("itoa:%s\n", myitoa(n, p));
	return 0;
}
