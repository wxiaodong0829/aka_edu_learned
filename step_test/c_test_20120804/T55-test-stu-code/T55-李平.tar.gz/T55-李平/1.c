/*************************************************************************
  > File Name   : 1.c
  > Author      : liping
  > Mail        : liping200909@yahoo.cn 
  > Created Time: Sat Aug  4 09:53:59 2012
 ************************************************************************/

#include<stdio.h>

int main(void)
{
	int n, flag;
	int i, j, p = 1;

	printf("Input the n:");
	scanf("%d", &n);

	printf(" 2");
	for (i = 3; i <= n; i+=2){
		flag = 1;
		for (j = 2; j*j <= i; j++)
			if(i%j == 0){
				flag = 0;
				continue;
			}
		if(flag == 1)
			printf("%4d",i);		
	}
	printf("\n");

	return 0;
}

