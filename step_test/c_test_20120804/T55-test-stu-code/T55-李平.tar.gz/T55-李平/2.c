/*************************************************************************
  > File Name   : 2.c
  > Author      : liping
  > Mail        : liping200909@yahoo.cn 
  > Created Time: Sat Aug  4 10:45:21 2012
 ************************************************************************/

#include<stdio.h>
#include<stdlib.h>

#define N 10

int main(void)
{
	int num[N], l;

	srand(time(NULL));
	for(l = 0; l < N; l++)
		printf("%4d", (num[l] = rand() % 100));
	printf("\n");
	

	int i,j,k,tmp;
	for (i = 0; i<10; i++)
	{
		tmp = i;
		for(j = i +1; j < 10; j++)
			if(num[tmp] > num[j])
				tmp = j;
		if (tmp != i)
			k = num[tmp],num[tmp]=num[i],num[i]=k;
	}
	for (i=0;i<10;i++)
		printf("%4d",num[i]);
	printf("\n");


	return 0;
}
