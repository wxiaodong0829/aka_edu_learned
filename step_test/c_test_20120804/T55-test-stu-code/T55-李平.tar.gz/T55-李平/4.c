/*************************************************************************
  > File Name   : 4.c
  > Author      : liping
  > Mail        : liping200909@yahoo.cn 
  > Created Time: Sat Aug  4 16:51:05 2012
 ************************************************************************/

#include<stdio.h>
#define N 10
int main(void)
{
	char str[N];
	printf("Input the str:");
	scanf("%s",str);
	int i,max,tmp;

	for(i=0;i<strlen(str);i++){
		tmp = i;
		for (i=0;i<strlen(str);i++){
			if(strcmp(str[i],str[i+1]) > 0)
				max = str[i+1];
			if(tmp !=i)	
				max = str[tmp], str[tmp]=str[i],str[i]=max; 
		}
	}
	for(i=0;i<strlen(str);i++)
		printf("%s",str[i]);

	return 0;
}
