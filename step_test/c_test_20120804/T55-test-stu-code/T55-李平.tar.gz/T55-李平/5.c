/*************************************************************************
    > File Name   : 5.c
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 17:08:40 2012
 ************************************************************************/

#include<stdio.h>
#define N 10
char fun(char s[])
{
	int i,len,m;
	char tmp;
	
	len = strlen(s)-1;
	for (i=len-1;i>=0;i--)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			tmp = s[i];
			for(m=i;m<len;m++)
				s[m] = s[m+1];
			s[len] = tmp;
			len--;
		}
	}
	printf("%s\n",s);
	return 0;
			
}
int main(void)
{
	char str[] = "asd123fgh543de";
	fun(str);
	return 0;
}
