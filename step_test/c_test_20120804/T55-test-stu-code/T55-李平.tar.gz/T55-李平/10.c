/*************************************************************************
  > File Name   : 10.c
  > Author      : liping
  > Mail        : liping200909@yahoo.cn 
  > Created Time: Sat Aug  4 14:47:33 2012
 ************************************************************************/

#include<stdio.h>
#include<stdio.h>

char buf[4] = {'+', '-', '*', '/'};
int main(void)
{

	int a, b, c;
	char type;

	while ((type = buf) != EOF){
		switch (type){
			case '+':
				return c = a + b;
				break;
			case '-':
				return c = a - b;
				break;
			case '*':
				return c = a * b;
				break;
			case '/':
				return c = a / b;
				break;
			case '#':
				break;
		}
	}
	printf("enter two number:");
	scanf("%d %d", &a, &b);

	printf("%d\n",c);
	return 0;
}
