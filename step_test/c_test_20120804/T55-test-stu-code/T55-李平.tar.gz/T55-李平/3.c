/*************************************************************************
    > File Name   : 3.c
    > Author      : liping
    > Mail        : liping200909@yahoo.cn 
    > Created Time: Sat Aug  4 15:52:03 2012
 ************************************************************************/

#include<stdio.h>

#define N 25

void select(int num[])
{
	int i,j,k,tmp;
	for (i = 0; i<N; i++)
	{
		tmp = i;
		for(j = i +1; j < N; j++)
			if(num[tmp] > num[j])
				tmp = j;
		if (tmp != i)
			k = num[tmp],num[tmp]=num[i],num[i]=k;
	}
	for (i=0;i<N;i++)
		printf("%4d",num[i]);
	printf("\n");
}

int main(void)
{
	int i, j;
	int arr[5][5];
	srand(time(NULL));
	for(j = 0; j < 5; j++)
	for(i=0;i<5;i++)
		printf("%4d", arr[i][j] = rand() % 100);
	printf("\n");

	select(arr);
	


	return 0;
}


