#include <stdio.h>
#include <string.h>
#define N 48
void itoa(int, int);
void reverse(char s[]);
void swap(char s[], int, int);

char s[N];
int main()
{
	itoa(-123, 2);
	return 0;
}

void itoa(int n, int base)
{
	int i = 0, sign;
	char c;
	if((sign = n) < 0) n = -n;
	do{
	switch(c= n % base){
		case 0: case 1: case 2: case 3: case 4:
		case 5: case 6: case 7: case 8: case 9:
			s[i++] = c + '0'; break;
		case 10: case 11: case 12:
		case 13: case 14: case 15:
			s[i++] = c + 'a' - 10; break;	
		}
	}while((n /= base) > 0);
		if(sign < 0) s[i++] = '-';
		s[i] = '\0';
		reverse(s);
		printf("%s\n", s);

}

void reverse(char s[])
{
	int l, r;
	r = strlen(s) - 1;
	l = 0;
	swap(s, l++, r--);
}

void swap(char s[], int l, int r)
{
	char tmp = s[l]; s[l] = s[r]; s[r] = tmp;
}
