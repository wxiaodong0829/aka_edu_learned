#include <stdio.h>
#include <time.h>
#define N 5

int arr[N][N];
void init(int (*arr)[5], int row)
{
	int i, j;
	srand(time(NULL));
	for(i = 0; i < row; i++){
		for(j = 0; j < 5; j++)
			arr[i][j] = rand()%100;	
	}
}

void show(int (*arr)[5], int row)
{
	int i, j;
	for(i = 0; i < row; i++){
		for(j = 0; j < 5; j++)
		printf("%4d", arr[i][j]);
		printf("\n");
	}
}

void sort(void *p, int len)
{
	int *start = p, i, j, tmp, pos;
	for(i = 0; i < len - 1; i++){
		pos = i;
		for(j = i + 1; j < len; j++)
			if(start[pos] > start[j])
				pos = j;
		if(pos != i){
			tmp = start[pos];
			start[pos] = start[i];
			start[i] = tmp;
		}
	}

}

int main()
{
	int i;
	init(arr, 5);
	show(arr, 5);
	printf("\n");
	for(i = 0; i < 5; i++)
		sort(arr[i], 5);
	show(arr, 5);
	printf("\n");
	sort(arr, 5 * 5);
	show(arr, 5);
}
