#include <stdio.h>
#include <string.h>
#define N 100

int main(void)
{
	int i, j;
	char max; 
	char s[N];
	char t[N];
	scanf("%s", s);	
	max = s[0];
	for(i = 0; i < strlen(s) - 1; i++){
		if(max < s[i])
		max = s[i];
	}
	j = 0; i = 0;
	while(s[i] != '\0'){
		t[0] = max;
		if(s[i] == max)
			i++;
		t[j + 1] = s[i];
		i++; j++;
		}
	printf("%s\n", t);
	return 0;
}
