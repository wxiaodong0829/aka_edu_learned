#include <stdio.h>
#include <string.h>
#include <ctype.h>
#define N 100

int main()
{
	int i, j, end, tmp;
	char s[N];
	scanf("%s", s);
	for(i = end = strlen(s) - 1; i >= 0; i--){
		if(isdigit(s[i])){
			tmp = s[i];
			for(j = i; i < end; i++)
				s[i] = s[i + 1];
			s[end--] = tmp;
		}
	}
	printf("%s\n", s);
	return 0;
}
