#include <stdio.h>
#include <string.h>
#define N 1024

void dollars(char *, char const *);

int main(int argc, char *argv[])
{
	char src[N];
	char dest[N];
	strcpy(src, argv[1]);
	if(argc == 2){
	dollars(dest, src);
	printf("%s\n", dest);
	}
	return 0;	
}

void dollars(char *dest, char const *src)
{
	int i, len;
	char c;
	len = strlen(src);
	*dest++ = '$';
	if(len >= 3){
		for(i = len - 2; i > 0;){
			*dest++ = *src++;
			if(--i > 0 && i % 3 == 0)
				*dest++ = ',';
		}
	}
	else
		*dest++ = '0';

	*dest++ = '.';
	*dest++ = len < 2 ? '0' : *src++;
	*dest++ = len < 1 ? '0' : *src;
	*dest = 0;
		
}
