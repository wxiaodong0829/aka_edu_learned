#include <stdio.h>
#include <string.h>
#include <time.h>
#define N 10
int num[N];
void swap(int l, int r)
{
	int tmp = num[l]; num[l] = num[r]; num[r] = tmp;
}
void init(int l, int r)
{
	int i;
	srand(time(NULL));
	for(i = l; i <= r ; i++)
		num[i] = rand()%100;
}

void show(int l, int r)
{
	int i;
	for(i = 0; i <= r ; i++)
		printf("%4d", num[i]);
	printf("\n");
}
void sort1(int l, int r)
{
	int i, j, tmp;
	for(i = 0; i < r - 1; i++){
		for(j = 0; j < r - i - 1; j++){
			if(num[j] > num[j + 1])
				swap(j, j + 1);
		}
	}
}

int partition(int l, int r)
{
	int i, j, tmp;
		for(j = l, i = j + 1; i <= r; i++)
			if(num[i] < num[l])
			swap(++j, i);

		swap(l, j);
		return j;
}

void sort2(int l, int r)
{
	if(l >= r) return;
	int k = partition(l, r);
	sort2(l, k - 1);
	sort2(k + 1, r);
}

int main(void)
{
	init(0, 9);
	show(0, 9);
	sort1(0, 9);
	show(0, 9);
	sort2(0, 9);
	show(0, 9);
	return 0;
}
