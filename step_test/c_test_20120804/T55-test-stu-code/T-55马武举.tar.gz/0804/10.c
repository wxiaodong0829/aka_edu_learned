#include<stdio.h>
int main(void)
{
   int x,y;
   char p;
   printf("Input the first number:  \n");
   scanf("%d",&x);

   printf("Input the second number:  \n");
   scanf("%d",&y);
   getchar();
   p=getchar();
   switch(p)
   {
   case '+':
   printf("%d+%d=%d\n",x,y,x+y);
   break;
   
   case '-':
   printf("%d-%d=%d\n",x,y,x-y);
   break;
 
   case '*':
   printf("%d*%d=%d\n",x,y,x*y);
   break;
   
   case '/':
   printf("%d/%d=%d\n",x,y,x/y);
   break;
  
   case '#':
   break;
  }
   return  0;
}  
   
