#include<stdio.h>
int main(void)
{
    int i, j,n;
    printf("n:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
       for(j=2;j<=i;j++)
       {
          if(i%j==0)
          break;
       }
       if(i==j)
       printf("%d\n",i);
       else
           continue;
    }
    return 0;
}
