#include <stdio.h>
fun(char *p)
{
     char max,*q;
     int i=0;
     max=p[i];
     while(p[i]!='\0')
     {
         if(max<=p[i])
         {
             max=p[i];
             q=p+i;
         }
         i++;
     }
     while(q>p)
     {
         *q=*(q-1);
         q--;
     }
     p[0]=max;
     return 0;
}
  main()
{
     char str[50];
     printf("Input: ");
     scanf("%s",str);
     fun(str);
     printf("%s\n",str); 
     return 0 ;
}

 


   
   



