#include<stdio.h>
int main(void)
{ 
   int num[10];
   int i,j,k;
   printf("Input 10 number:\n");
   for(i=0;i<10;i++) 
   scanf("%d",&num[i]);
   for(j=1;j<9;j++)
   {
      for(i=1;i<=10-j;i++)
         if(num[i]>num[i+1])
         {
           k=num[i];
           num[i]=num[i+1];
           num[i+1]=k;
          }
   }
    for(i=1;i<10;i++)
    printf("%d\n",num[i]); 

  return 0;
}
