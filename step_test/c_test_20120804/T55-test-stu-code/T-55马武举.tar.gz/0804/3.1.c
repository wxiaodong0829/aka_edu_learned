#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int compare(const void *a,const void *b)
{
    return *(int*)a-*(int*)b;
}
int main()
{
    int i,j;
    int arr[5][5];
    for(i=0;i<5;i++)
    for(j=0;j<5;j++)
    printf("排序前： \n");
    for(i=0;i<5;i++)
   {
       for(j=0;j<=5;j++)
       printf("%d\n",arr[i][j]);
       puts("");
   }
   qsort(arr[i],5,sizeof(int),compare);
   puts("排序后：");
   for(i=0;i<5;i++)
   {
      for(j=0;j<5;j++)
      printf("%d\n",arr[i][j]);
      puts("");
   }
      return 0;
}

