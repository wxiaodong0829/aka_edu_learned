#include <stdio.h>
#include <string.h>
#include <ctype.h>

char fun(char   src[])
{
  
    
    int i, j, end;
    char tmp;
    for(i = end = strlen(src) - 1; i >= 0; i--){
        if(isdigit(src[i])){
            tmp = src[i];
            for(j = i; i < end; i++)
                src[i] = src[i + 1];

            src[end--] = tmp;
        }
    }
    printf("src:%s\n", src);
    return 0;
}

int main()
{
    char src[100], tmp;
    printf("Input src:");
    scanf("%s", src);
    fun(src);
   
    printf("%s\n",src);
    return 0;
}
