#include <stdio.h>
#define N 1

struct stud
{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
};

void readrec(struct stud *stu)
{
	int i, j;
	int sum;

	for(i = 0; i < N; i++)
	{
		sum = 0;
		scanf("%d%s", &stu[i].id, stu[i].name);		
		for(j = 0; j < 4; j++)
		{
			scanf("\t%d", &stu[i].s[j]);
			sum += stu[i].s[j];
		}
		stu[i].ave = sum / 4;
	}
}

void writerec(struct stud *stu)
{
	int i, j ;
	for(i = 0; i < N; i++)
	{
		printf("%d\t%s\t", stu[i].id, stu[i].name);
		for(j = 0; j < 4; j++)
		{
			printf("%d\t", stu[i].s[j]);
		}
		printf("%f\n", stu[i].ave);
	}
}

int main(int argc, char *argv[])
{
	struct stud arr[N];	
	readrec(arr);
	writerec(arr);
	return 0;
}

