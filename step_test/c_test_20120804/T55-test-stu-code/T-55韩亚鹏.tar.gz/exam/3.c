#include <stdio.h>
#include <stdlib.h>

void init(int (*arr)[5])
{
	int i, j;
	srand(time(NULL));
	for(i=0; i<5; i++)
		for(j=0; j<5; j++)
			arr[i][j]=rand()%100;
}
void show(int (*arr)[5])
{
	int i, j;
	for(i=0; i<5; i++){
		for(j=0; j<5; j++)
			printf("%4d",arr[i][j]);
		printf("\n");}
}

void sel(int a[],int n)
{
	int i,j,k,tmp;
	for(i=0;i<n-1;i++)
	{
		k=i;
		for(j=i+1;j<n;j++)
			if(a[j]<a[k]) k=j;
		if(k!=i) { tmp=a[i];a[i]=a[k];a[k]=tmp;  }
	}
}

int main()
{
	int arr[5][5];
	int i;
	init(arr);
	for (i=0; i<5; i++)
		sel(arr[i], 5);
	show(arr);
	printf("****************************\n");
	sel(arr[0], 25);
	show(arr);
	return 0;
}
