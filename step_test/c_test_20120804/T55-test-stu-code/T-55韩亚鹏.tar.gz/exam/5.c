#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
	char str[100]="asd123fgh543df", tmp;
	int i, j, end;
	for(i = end = strlen(str) - 1; i >= 0; i--){
		if(isdigit(str[i])){
			tmp = str[i];
			for(j = i; i < end; i++)
				str[i] = str[i + 1];
        str[end--] = tmp;
		}
	}
	printf("%s\n", str);
	return 0;
}
