#include <stdio.h>
void sort(int a[],int n);
void insert(int a[],int l,int r);
void shell(int a[],int l,int r);
void sel(int a[],int n);


int main()
{
	int num[10],i=0,len;
	srand(time(NULL));
	while(i<10)  num[i++]=rand()%100;
	i=0;
	while(i<10) printf("%d\n",num[i++]);
	// 	sort(num,9);
 //	insert(num,0,9); 
//	shell(num,0,9); 
  sel(num,9);
	printf("*********\n"); 

	i=0;
	while(i<10) printf("%d\n",num[i++]);
}


void sort(int a[],int n)
{
	int i,j,tmp;
	for(i=0;i<=n;i++)
		for(j=n-1;j>=i;j--)
			if(a[j]>a[j+1])
			{
				tmp= a[j];
				a[j]=a[j+1];
				a[j+1]=tmp;	
			}
}



void insert(int a[],int l,int r)
{
	int i,j,tmp; 
	for(j=l+1;j<=r;j++)
	{
		tmp=a[j];
		for(i=j-1;i>=0&&a[i]>tmp;i--) a[i+1]=a[i];
		a[i+1]=tmp;
	}

}


void shell(int a[],int l,int r)
{
	int gap,i,j,tmp;
	for(gap=(r-l+1)/2;gap>=1;gap/=2)
	{
		for(j=l+gap;j<=r;j++)
		{
			tmp=a[j];
			for(i=j-gap;i>=0&&a[i]>tmp;i--) a[i+gap]=a[i];
			a[i+gap]=tmp;
		}
	}

}



void sel(int a[],int n)
{
int i,j,k,tmp;
for(i=0;i<=n;i++)
 {
     k=i;
		for(j=i+1;j<n;j++)
		if(a[j]<a[k]) k=j;
		if(k!=i) { tmp=a[i];a[i]=a[k];a[k]=tmp;  }
 }
}


