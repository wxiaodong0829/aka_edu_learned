#include <stdio.h>
void max(char s[]);

int main()
{
	char s[]="chyab";
	printf("%s\n",s);
	max(s);
}


void max(char s[])
{
   
 int i=0,max=0, k;
 char tmp;
 while(s[i++]!='\0')  if(s[i]>max) {max=s[i];k=i;}
 tmp= s[k];
 while(k!=0) {s[k]=s[k-1];k--;} s[k]=tmp;
 printf("%s\n",s);
}
