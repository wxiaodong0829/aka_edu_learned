#include <stdio.h>
#include <string.h>

char s[10];
void myitoa(int n);
void reverse(char s[]);

int main()
{
	myitoa(456);
}


void myitoa(int n)
{
	int sign, i = 0;	
	if((sign = n) < 0) n = -n;
	do
	{
		s[i++]=n % 10 + '0';
	} while((n /= 10) > 0);
	if(sign < 0) s[i++] = '-';
	s[i] = '\0';
	
	reverse(s);
	printf("%s\n",s);
}

void reverse(char s[])
{
	int i,j,n=strlen(s), tmp;
	for (i=0, j=n-1; i<j; i++, j--)
		tmp = s[i], s[i] = s[j], s[j] = tmp;
}
