#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
	int num[10], i, j, tmp, pos;

	srand(time(NULL));
	for(i = 0; i < 10; i++)
		printf("%d ", num[i] = rand() % 50);
	printf("\n");

	for(i = 0; i < 9; i++){
		pos = i;
		for(j = i + 1; j < 10; j++){
			if(num[pos] > num[j]){
				pos = j;
			}
		}
		if(pos != i){
			tmp = num[pos];
			num[pos] = num[i];
			num[i] = tmp;
		}
	}
	for(i = 0; i < 10; i++)
		printf("%d ", num[i]);
	printf("\n");

	return 0;
}
