#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(void)
{
	int num[10], i, j, tmp;

	srand(time(NULL));
	for(i = 0; i < 10; i++)
		printf("%d ", num[i] = rand() % 50);
	printf("\n");

	for(i = 0; i < 9; i++){
		for(j = 0; j < 9 - i; j++){
			if(num[j] > num[j + 1]){
				tmp = num[j];
				num[j] = num[j + 1];
				num[j + 1] = tmp;
			}
		}
	}
	for(i = 0; i < 10; i++)
		printf("%d ", num[i]);
	printf("\n");

	return 0;
}
