#include<stdio.h>
#include<math.h>
int main(void)
{

	int i,j,n;
	printf("please input n :");
	scanf("%d",&n);

	for(i = 0;i <= n; i++)
	{
		for(j = 2; j<=sqrt(i); j++)
			if(i % j == 0)
				break;
			else if(j > sqrt(i) - 1)
			{
				printf("%d",i);
				
				
			}
			else
				continue;

	}
	return 0;
}
