#include <stdio.h>
#define N 10
int maopao(void)
{
	int a[N],i,j,tmp;
	printf("a[N]=");
	for (i=0;i<N;i++)
	{
		scanf("%d",&a[i]);
	}
	for (i=0;i<N-1;i++)
	{
		for(j=N-2;j>=i;j--)
		{
			if(a[j+1]<a[j])
			{
				tmp=a[j+1];
				a[j+1]=a[j];
				a[j]=tmp;}
		}
	}
	for (i=0;i<N;i++)
		printf("%d",a[i]);
	printf("\n");
}
int xuanzhe(void)
{
		int b[N] i, j,tmp;
		int min;
		printf("b[N]=");
		for (i=0;i<N;i++)
		{
		scanf("%d",&b[i]);}
		for(i = 0; i < N - 1; i++)
		{	min = i;
			for(j = i + 1; j < N; j++)
			{
				if(b[j] < b[min])	

				{
					min = j;
				}
			}
			if (min!=i)
			{
				tmp=b[min];
				b[min]=b[i];
				b[i]=tmp;
			}
		}
}	
int main(void)
{
	maopao();
	xuanzhe();
	return 0;
}
