#include <stdio.h>
#define N 10
#include <string.h>
struct stud {
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
}a[10];
void readrec (struct stud *p)
{
	int i,j,sum;sum=0;
	p=a;
	for (i=0;i<N;i++)
	{	scanf("%hu %s \n",&p[i].id,&p[i].name);
	for (j=0;j<4;j++)
	{
		scanf("%d",&p[i].s[j]);
		sum=sum+p[j].s[j];
	}
	p[j].ave=sum/4;

}
}
int main(void )
{
	struct stud a[N];
	readrec(a);
	return 0;
}
void write (struct stud *p1)
{
}
