#include <stdio.h>
#include <string.h>
#define N 100
int main(void)
{
int i;
char  a[N]="hello word",tmp;
char max='\0';
for (i=N-1;i>=0;i--)
{
	if (a[i+1]>a[i])
	{
		tmp=a[i];
		a[i]=a[i+1];
		a[i+1]=tmp;
	}
}
printf("%s\n",a);
return 0;
}
