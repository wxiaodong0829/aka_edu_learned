#include<stdio.h>

void counter();
void add();
void sub();
void mul();
void div();

int main(void)
{
	counter();
	return 0;
}

void counter()
{
	char c;
	while(scanf("%c", &c))
	{
		switch(c)
		{
			case '+':add();break;
			case '-':sub();break;
			case '*':mul();break;
			case '/':div();break;
			case '#':return;break;
			default:break;
		}
	}
}

void add()
{
	int a, b;
	scanf("%d%d", &a, &b);
	printf("%d\n", a+b);
}

void sub()
{
	int a, b;
	scanf("%d%d", &a, &b);
	printf("%d\n",a-b);
}

void mul()
{
	int a, b;
	scanf("%d%d", &a, &b);
	printf("%d\n", a*b);
}

void div()
{
	float a, b;
	scanf("%f%f", &a, &b);
	printf("%f\n", a/b);
}


