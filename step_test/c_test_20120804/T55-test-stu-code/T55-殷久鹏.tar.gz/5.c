#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{
	char src[100], tmp;
	int i, j, k;

	printf("plz input:");
	scanf("%s", src);

	for(i = k = strlen(src) - 1; i >= 0; i--)
	{
		if ( isdigit (src[i]) )
		{
			tmp = src[i];
			for(j = i; i < k; i++)
			src[i] = src[i + 1];
			src[k--] = tmp;
		}
	}
	printf("\nSrc:%s\n", src);
	return 0;
}
