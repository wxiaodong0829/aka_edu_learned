#include <stdio.h>
main()
{
	int m, n, i, prime;
	printf("n = ");
	scanf("%d",&n);
	printf("all of the primes from 1 to %d:\n",n);
	for(i=2;i<=n;i++)
	{
		prime = 1;
		for(m=2;m<i;m++)
		if(i%m==0)
		{	
			prime = 0;
			break;
		}
		if(prime==1)
		{
			printf("%4d",i);
		}
	}
	printf("\n\n");
}
