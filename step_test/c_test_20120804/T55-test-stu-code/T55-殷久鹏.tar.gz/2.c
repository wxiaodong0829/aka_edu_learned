#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void init (int num[10], int len)
{
	int i;
	srand(time (NULL));
	for(i=0;i<len;i++)
	num[i] = rand() % 100;
}

void show (int num[10], int len)
{
	int i;
	for (i=0;i<len;i++)
		printf("%5d",num[i]);
	printf("\n");
}
#if 0
void bubble_sort (int num[10], int len)
{
	int i, j, tmp;
	for(i=0;i<len-1;i++)
	{
		for(j=0;j<len-i-1;j++)
		{
			if (num[j] > num[j+1])
			{tmp=num[j];num[j]=num[j+1];num[j+1]=tmp;}
		}
	}
}

#endif


#if 1
void c_sort (int num[10], int len)
{
	int i, j, k, tmp;
	for (i=0;i<len-1;i++)
	{
	k=i;
	for(j=i+1;j<len;j++)
		if(num[j]<num[k])
			k = j;
	if(k != i)
	{tmp = num[i]; num[i] = num[k]; num[k] = tmp;}
	}

}


#endif


int main()

{
	int num[10];
	init (num, 10);
	show (num, 10);
//	bubble_sort(num, 10);
	c_sort(num, 10);
	show (num, 10);
	return 0;

}

