#include <stdio.h>
#include <string.h>

void max_to_first(char str[]);

int main(void)
{
	char str[] = "chyab";
	printf("%s\n", str);
	max_to_first(str);
	printf("%s\n", str);
}

void max_to_first(char str[])
{
	char max = str[0];
	int i, j;

	for(i = 0; str[i] != '\0'; i++)
		if(max < str[i])
			max = str[i], j = i;

	for(i = 0; i < j; i++)
		str[j-i] = str[j-i-1];

	str[0] = max;
}
