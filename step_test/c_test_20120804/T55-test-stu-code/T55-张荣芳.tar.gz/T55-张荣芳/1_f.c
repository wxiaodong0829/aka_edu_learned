#include<stdio.h>

#define PRINT(s) printf("%d ",s)

void prime(int n)
{
	int i,j;
	int flag;
	PRINT(2);
	for(i=3; i <= n; i += 2){
		flag =1;
		for(j=2;j*j < i;j++)
		{
			if(i%j == 0) {
				flag =0;
				continue;
			}
		}
		if((j*j > i)&& (flag ==1)) PRINT(i);
	}
	printf("\n");
}
int main()
{
	int n;

	scanf("%d",&n);
	prime(n);	

	return 0;
}
