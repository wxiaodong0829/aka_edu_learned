#include<stdio.h>
#include<string.h>

#define N 20

void reverse(char p[])
{
	char tmp;
	int i, j, l;
	l = strlen(p);
	for(i=0,j=l-1;j>=i;i++,j--)
	{
		tmp = p[i];
		p[i] = p[j];
		p[j] = tmp;
	}
}
char * myitoa(int n, char *p)
{
	int sign;
	int i;
	 
	sign = n;
	if(n < 0) n = -n;
	i=0;
	do{
		p[i++] = n % 10 + '0';
	}while(n /= 10);
	if(sign < 0 ) p[i++] = '-';
	p[i] = '\0';
	reverse(p);	

	return p;
}
int main()
{
	int n;
	char str[N];
	char *p;
	scanf("%d",&n);
	p=myitoa(n,str);
	printf("%s\n",p);
	return 0;
}
