#include<stdio.h>
#include<string.h>

#define N 50
#define ISUPPER(a) ((a) >= 'A' && (a) <= 'Z' ? 1:0) 
#define ISLOWER(a) ((a) >= 'a' && (a) <= 'z' ? 1:0) 
#define ISALPHA(a) (ISUPPER(a)||ISLOWER(a)) 
char *mvdigit(char *s)
{
	char *str,tmp;
	str = s;
	int i,j,len,end;
	len = strlen(s);
	for(i = end = len - 1;i >=0; i--)
	{
		if(!ISALPHA(str[i])){
			tmp = str[i];
			for(j = i;j<end;j++)
				str[j] = str[j+1];
			str[end--] = tmp;
		}
	}
	return str;
}
int main()
{
	char s[N];// = "asd123fgh543df";
	char *p;
	scanf("%s",s);
//	printf("%s\n",s);
	p=mvdigit(s);
	printf("%s\n",p);
	return 0;
}
