#include<stdio.h>
#include<string.h>

#define N 2
typedef struct stud NODE;
struct stud{
	unsigned short id;
	char name[N];
	int s[4];
	double ave;
};
double avg(int a[])
{
	int i;
	double avge=0.0;
	for(i=0;i<4;i++)
		avge += a[i];
	avge =(double)(avge/4);
		
	return avge;
}
NODE *readrec(NODE *stu, int n)
{
	int i,j;
	for(i=0; i<N;i++)
	{
		printf("id	name\n");
		scanf("%d	%s",&(stu[i].id),stu[i].name);
		printf("\nfour grade:");
		for(j=0;j<4;j++)
			scanf("%d",&(stu[i].s[j]));
		stu[i].ave = avg(stu[i].s);
	}
	return stu;
}	
NODE *writerec(NODE *stu, int n)
{
	int i,j;
	for(i=0; i<N; i++)
	{
		printf("id	name\n");
		printf("%d	%s",stu[i].id,stu[i].name);
		printf("\nfour grade:\n");
		for(j=0;j<4;j++)
			printf("s[%d] :%d ",i,stu[i].s[i]);
		printf("ave = %lf\n\n",stu[i].ave);
	}
	return stu;
}
int main()
{
	NODE student[N];
	readrec(student,N);
	writerec(student,N);

	return 0;
}
