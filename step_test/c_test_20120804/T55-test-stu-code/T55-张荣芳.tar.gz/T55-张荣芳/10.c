#include<stdio.h>
#include<string.h>

int i=0;
int eval(char s[])
{
	while(s[i]==' ') i++;
	switch(s[i])
	{
		case'0':case'1':case'2':case'3':case'4':
		case'5':case'6':case'7':case'8':case'9':
			return s[i++]-'0';
		case'+':{i++;return eval(s)+eval(s);}
		case'-':{i++;return eval(s)-eval(s);}
		case'*':{i++;return eval(s)*eval(s);}
		case'/':{i++;return eval(s)/eval(s);}
		case'#':break;
	}
	return 0;
}

int main()
{
	char s[] = "+ 2 3";
	int a;
	a = eval(s);
	printf("%d\n",a);

	return 0;
}
