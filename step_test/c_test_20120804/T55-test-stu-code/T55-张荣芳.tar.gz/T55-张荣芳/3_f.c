#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define PRINT(s) printf("%4d",s)
#define N 5

int arr[N][N];

void show()
{
	int i,j;
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			PRINT(arr[i][j]);
		}
		printf("\n");
	}

	printf("\n");
}
void init()
{
	int i,j;
	srand(time(NULL));
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			arr[i][j] = rand()%100;
		}
	}
}
void sort(int *a,int n)
{
	int i,j,k;
	int tmp;
	for(i=0;i<=n;i++)
	{
		k=i;
		for(j=i+1;j<n;j++){
			if(a[j]<a[k])
				k = j;
		}
		if(k!=i){
			tmp = a[i]; 
			a[i] = a[k];
			a[k] = tmp;
		}
	}

}
void sortline(int *a[])
{
	int i;
	int *p;
	p = (int *) a;
	for(i=0;i<N*N;i+= 5)
	{
		sort(p+i,5);
	}
	show();	
}
void sortall(int *a[])
{
	int i,j,k;
	sort(a,N*N);
	show(arr);	
}
int main()
{
	init();
	show();
	printf("sort a line\n");
	sortline((int **)arr);
	printf("sort all \n");
	sortall((int **)arr);

	return 0;
}
