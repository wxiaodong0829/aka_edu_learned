#include<stdio.h>
#include<string.h>

#define MAXSIZE 20

char * maxstr(char *s)
{
	int i,p,j;
	int l = strlen(s);
	char max;
	max = s[0];
	for(i=0;i<l;i++)
	{
		if(max < s[i]){
			p=i;
			max = s[i];
		}
	}
	for(j=p-1;j>=0; j--)
	{
		s[j+1] = s[j];
	}
	s[0] = max;
	 return s;
}
int main()
{
	char s[MAXSIZE]; //="chyab";

	scanf("%s",s);
	maxstr(s);
	printf("%s\n",s);
	
	return 0;
}
