#include<stdio.h>

#define PRINT(s) printf("%d ",s)
#define N 10

int num[N];

void show()
{
	int i;
	for(i=0;i<N;i++)
		PRINT(num[i]);

	printf("\n");
}
void init()
{
	int i;
	srand(time(NULL));
	for(i=0;i<N;i++)
		num[i] = rand()%100;
}

void sort1(int a[])
{
	int i,j;
	int tmp;
	for(i=0;i<=N;i++)
	{
		for(j=N-1;j>i;j--)
		{
			if(a[j-1]>a[j]){
				tmp = a[j];
				a[j] = a[j-1];
				a[j-1] = tmp; 
			}
		}
	}
	printf("冒泡排序：\n");
	show(a);
}
void sort2(int a[])
{
	int i,j,k;
	int tmp;
	for(i=0;i<=N;i++)
	{
		k=i;
		for(j=i+1;j<N;j++){
			if(a[j]<a[k])
				k = j;
		}
		tmp = a[i]; 
		a[i] = a[k];
		a[k] = tmp;

	}
	printf("选择排序:\n");
	show(a);
}


int main()
{
	init();
	show();
	sort1(num);
	sort2(num);
	return 0;
}
