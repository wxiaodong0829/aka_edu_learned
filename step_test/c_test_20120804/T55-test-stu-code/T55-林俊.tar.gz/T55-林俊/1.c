#include<stdio.h>

int main(void)
{
		int n;
		scanf("%d",&n);
		primes_1(n);

		return 0;
}

void primes_1(int a)
{
		int i, j;
	    printf("2\n");
		for (i=3; i<=a; i+=2) {
		for (j=2; j*j<i; j++) if (i%j==0) break;
		if (j*j>i) printf("%d\n", i);
		}
}

/*void sushu(int n)
{
		int i;
		for(i=2; i<n; i++)
		{
				if(n%i!=0)
				
				if(i<sqrt(n))


		}
}
*/
