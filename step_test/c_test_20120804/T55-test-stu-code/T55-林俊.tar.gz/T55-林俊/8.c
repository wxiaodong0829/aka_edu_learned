#include <stdio.h>
#include <string.h>

#define N 1000

int main(int argc, char *argv[])
{
	char src[N];
	char dest[N];
	if(argc != 2)
	{
		fprintf(stderr,"Usage:%s string delim subdelim\n", argv[0]);
		return 1;
	}
	strcpy(src, argv[1]);
	dollar(dest, src);
	printf("dollars:%s\n", dest);
	
	return 0;
}
void dollar(char *dest, char const *src)
{
	int length;
	*dest++ = '$';
	length = strlen(src);
	if(length >= 3){
		int i;
		for(i = length - 2; i > 0;)	
		{*dest++ = *src++;
			if(--i > 0 && i % 3 == 0){
				*dest++ = ',';
			}
		}
	}
	else{
		*dest++ = '0';
	}
	*dest++ = '.';	*dest++ = (length<2) ? '0': *src++;
	*dest++ = len < 1 ? '0': *src;*dest = 0;
}
