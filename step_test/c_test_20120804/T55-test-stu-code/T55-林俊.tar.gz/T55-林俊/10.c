#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void parse(char * buf, char *argv[])
{
		int argc = 0;
		int i;
		if(buf[0]!= ' ')
		{
					argv[0]= &buf[0];
					argc = 1;
		}
		for(i=1;buf[i] != '\0';i++){

		if(buf[i]!=' ' && (buf[i-1] == ' ' || buf[i-1] == '\0'))
			{		
						    argv[argc] = &buf[i];
						    argc++; 
			}
			else if(buf[i] == ' ' && buf[i-1]!=' ')
			{	
				buf[i] = '\0';
			} 
		}
}


int main(void)
{
	char buf[32]={"5 + 8 "} ;
	int argc;
	char *argv[10];
	int i;char c;int result=0;
	//scanf("%s",buf);
//	buf = getline();
/*	while(scanf("%s",buf)){
	parse(buf, argv);
	printf("%s \n", argv[1]);
	}
	*/
	printf("%s\n", buf);
	parse(buf, argv);
	printf("%s",argv[1]);
//	while((c=getchar())=='#'){
//	return 0;
//	}
	while(1){
	if(argv[1]=="+")
	{
			printf("jiafa:\n");
			result=	add((int)(*argv[0]),(int)(*argv[2]));
			printf("%d\n",result);
	}
	else if(argv[1]=="-")
	{
			sub((int)(*argv[0]),(int) (*argv[2]));
			printf("%d\n",result);
	}
	else if(argv[1]=="*")
	{
			mul((int)(*argv[0]),(int) (*argv[2]));
			printf("%d\n",result);
	}
	else if(argv[1]=="/")
	{
			div_1((int)(*argv[0]),(int) (*argv[2]));
			printf("%d\n",result);
	}

	while((c=getchar())=='#'){return 0;}
	}
//	while((c=getchar())=='#'){
//	return 0;
//}
return 0;
}


int add(int a, int b)
{
return a+b;
}

int sub(int a, int b)
{
		return a-b;
}

int mul(int a, int b)
{
		return a*b;
}

int div_1(int a,int b)
{
		return (int)(a/b);
}
