#ifndef __UNION_H__
#define __UNION_H__

#define MAX 100

int charcmp(const void *ai, const void *aj)
{
		return *(char *)ai - *(char *)aj ;
} 

void init_arr(int (*par)[5], int row)
{
	int i, j;

	srand(time(NULL));
	for(i = 0; i < row; i++){
		for(j = 0; j < 5; j++)
			par[i][j] = rand() % 100;
	}
}
void print_arr(int (*par)[5], int row)
{
	int i, j;

	for(i = 0; i < row; i++){
		for(j = 0; j < 5; j++)
			printf("%d ", par[i][j]);
		printf("\n");
	}
}

#endif
