#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "union.h"


int main(void)
{
	int arrary[5][5], i;
	
	init_arr(arrary, 5);
	print_arr(arrary, 5);
	for(i = 0; i < 5; i++)
		sort(arrary[i], 5);
	print_arr(arrary, 5);
	Csort(arrary, 5 * 5);
	print_arr(arrary, 5);


	return 0;
}
void Csort(int len, void *p)
{
	int *start = p, i, j, tmp, pos;

	for(i = 0; i < len - 1; i++)
	{
		pos = i;
		for(j = i + 1; j < len; j++)
			if(start[pos] > start[j])
				pos = j;
		if(pos != i)
		{
			tmp = start[pos];
			start[pos] = start[i];
			start[i] = tmp;
		}
	}
}
