#include <limits.h>
#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#define N 48
char s[N];



void reverse(char s[])
{
		    int i, j, n=strlen(s), tmp;
			    for (i=0, j=n-1; i<j; i++, j--)
						        tmp = s[i], s[i] = s[j], s[j] = tmp;
}
void myitoa(int n, char *p)
{

		    int i=0, j, sign; char c;
			int base;
		//	for(j=0;p[j]!='\0';j++){
			base = (int)p;
			    if ((sign=n) < 0) n = -n;
				    do {
				    switch((c=n%base)) {
					case 0: case 1: case 2: case 3: case 4:
					case 5: case 6: case 7: case 8: case 9:
					s[i++] = c + '0'; break;
					case 10: case 11: case 12:
					case 13: case 14: case 15:
					s[i++] = c + 'a' - 10; break;
																								        }
									    } while ((n/=base) > 0);
					    if (sign < 0) s[i++] = '-';
					    s[i] = '\0';
						    reverse(s);
							    printf("%s\n", s);
		
}
int main()
{
	char * s;
	int n;
	n=16;
	s=(char *)n;
	    myitoa(123, s);
		return 0;
}
