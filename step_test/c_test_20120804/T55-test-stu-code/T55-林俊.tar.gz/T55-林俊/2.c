#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 10
int Msort(int b[])
{
    
return 0; 
}


void put(int a[])
{
		int k;k=0;
		for(k=9;k>=0;k--)
        printf("%d ",a[k]);


}

int  Csort()
{
		 int i;
		 int a[N];
		 int k,j,temp,flag;
		 i=temp=flag=0;
		 srand(time(NULL));
		for (i=0; i<N; i++) {a[i] = rand()%100;
		}
		for(k=1;k<N;k++)
		{
				for(j=0;j<N-1;j++){
				if((a[k]-a[j])<0)
				{	//	printf("%d ",a[k]);
						temp=a[j];
						a[j]=a[k];
						a[k]=temp;
                       // printf("%d ",a[k-1]);
				}
				}
			//	else 
			//	{
			//			printf("%d ",a[k-1]);
			//	}

		}
		put(a);
	//	put(a);	
         return 0;
}


int main(void)
{
//	int num[N];
		//init(num);
//	int i;//int num[N];
//	srand(time(NULL));
//	  for (i=0; i<N; i++) {num[i] = rand()%100;
//	  }
		//init();
	Csort();

//	return 0;

}
