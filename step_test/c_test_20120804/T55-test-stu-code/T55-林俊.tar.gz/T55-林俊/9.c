#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef int *   va_list;
#define va_start(ap, A)     ap = &(A);
#define va_arg(ap, T)   (*(T *)(ap = ((char *)ap + sizeof(T))))
#define va_end(ap)      ap = (void *)0

char *vstrcat(int len,const char * first, ...)
{
		int i;

		char *s[10]; char *c=malloc(100);
		va_list p;
		va_start(p, len);
		char * val;
		for(i=0; i<len;i++){
		val = va_arg(p,char *);
        
        if(val == NULL)
		break;
		printf("%s",val);
}
        printf("\n");
		va_end(p);
		return val;

}


int main(void)
{				   
			vstrcat(3,"adfsf","afd", "awfre");
			return 0;
}
