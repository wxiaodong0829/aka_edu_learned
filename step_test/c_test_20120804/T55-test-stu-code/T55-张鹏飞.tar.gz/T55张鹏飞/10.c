#include <stdio.h>

typedef float *F(float x, float y);
float x, y;
F *add()
{
	printf("%.2f\n", x+y);
}
F *sub()
{
	printf("%.2f\n", x-y);
}
F *mul()
{
	printf("%.2f\n", x*y);
}
F *div()
{
	printf("%.2f\n", x/y);
}
int main (void)
{
	char a;
	
	do {
	printf("please input one of ('+', '-', '*', '/'):");
	scanf("%c", &a);
	switch(a)
		{
		case '+':
			printf("please input two number:");
			scanf("%f %f", &x, &y);
			add(x, y);
			break;
		case '-':
			printf("please input two number:");
			scanf("%f %f", &x, &y);
			sub(x, y);
			break;
		case '*':
			printf("please input two number:");
			scanf("%f %f", &x, &y);
			mul(x, y);
			break;
		case '/':
			printf("please input two number:");
			scanf("%f %f", &x, &y);
			div(x, y);
			break;
		case '#':
			return 0;
				}
	}while(1);
	return 0;
}


