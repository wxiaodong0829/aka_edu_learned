#include <stdio.h>
#include <time.h>
int i, j;
int arr[5][5];
void init()
{
		srand(time(NULL));
			for (i=0; i<5; i++)
				for(j=0; j<5; j++)
				arr[i][j]=rand()%100;
}
void show()
{
		for (i=0; i<5; i++)
		{
			for(j=0; j<5; j++)
					printf("%d\t ", arr[i][j]);
			printf("\n");
		}
}
void choose1()
{
	int tmp, a, k;
	for (i=0; i<5; i++)
	{
		for(j=0; j<5; j++)						
		{
			a = j;
			for(k=j+1; k<5; k++)
			{
				if (arr[i][a]>arr[i][k])
					a=k;
			}
			if(a!=j)
			{
				tmp = arr[i][j];
				arr[i][j] = arr[i][a];
				arr[i][a] = tmp; 
			}
		}
	}
}
void choose2()
{
	int tmp, a, k;
	for (j=0; j<5; j++)
	{
		for (i=0; i<5; i++)
		{
				a = i;
				for(k=i+1; k<5; k++)
				{
					if (arr[a][j]>arr[k][j])
						a=k;
				}
				if(a!=i)
				{
					tmp = arr[i][j];
					arr[i][j] = arr[a][j];
					arr[a][j] = tmp; 
				}
		
		}
	}
}
int main()
{

	init(arr);
	printf("before sort:\n");
	show(arr);

	choose1(arr);
	printf("after 1 sort: \n");
	show(arr);

	choose2(arr);
	printf("after 2 sort: \n");
	show(arr);

	return 0;
}

