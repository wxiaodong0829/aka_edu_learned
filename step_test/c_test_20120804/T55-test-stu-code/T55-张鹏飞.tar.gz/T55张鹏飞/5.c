#include <stdio.h>
#include <string.h>
char str[100];
void fun (char s[])
{
	int i, r, l;
	char tmp;

	r=strlen(str)-1;

	for (i=r; i>=0; i--)
	{
		if(isdigit(str[i]))
		{
			tmp = str[i];
		   for (l=i; l<r; l++)	
			   str[l] = str[l+1];
		   str[r--] = tmp;
		}
	}

	printf("%s\n", str);
}

int main(void)
{
	printf("str:");
	scanf("%s", str);

	fun(str);

	return 0;
}
