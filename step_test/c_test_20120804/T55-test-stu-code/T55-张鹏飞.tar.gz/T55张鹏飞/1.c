#include <stdio.h>

int primes(int n)
{
	int count = 0;
	int i, j;

	for (i=2; i<=n; i++)
	{
		count = 1;
		if(i==2) ;
		else
		{
			for (j=2; j*j<=i; j++)
			{
				if (i%j == 0)
				{
					count = 0;
					continue;
				}
			}
		}
		if(count == 1)
			printf("%d\n",i);
	}


}
int main (void)
{
	int n;
	int i;

	printf("please input a number:");
		scanf("%d", &n);
	
	primes(n);
	return 0;
}

