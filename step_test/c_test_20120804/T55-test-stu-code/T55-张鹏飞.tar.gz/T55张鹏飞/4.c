#include <stdio.h>
#include <string.h>
#define N 100
char str[N];

void compare(char s[])
{
	int i, n, k;
	char tmp, max;

	n = strlen(str)-1;
	max = str[0];

	for (i=0; i<=n; i++)
	{
		if (max < str[i])
		{
			max =str[i];
				k = i;
		}
	}

	tmp = str[k];

	for (i=k; i>0; i--)
		str[i] = str[i-1];

	str[0] = tmp;

		printf("%s\n",str);
}


int main(void)
{
	
	printf("str:");
	scanf ("%s", str);

	compare(str);

	return 0;
}
