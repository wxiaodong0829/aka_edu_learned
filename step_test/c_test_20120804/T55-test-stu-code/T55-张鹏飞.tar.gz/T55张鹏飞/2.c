#include <stdio.h>
#include <time.h>

int num[10];
int i;

void init()
{
	srand(time(NULL));
	for (i=0; i<10; i++)
		num[i]=rand()%100;
}

void show(int a[])
{
	for (i=0; i<10; i++)
		printf("%d ", num[i]);
	printf("\n");
}

void bubble(int a[])
{
	int tmp;
	int j;
	for (j=0; j<10;j++)
	{
		for(i=9; i>=0; i--)
		{
			if(num[i] < num[i-1])
			{
				tmp = num[i];
				num[i] = num[i-1];
				num[i-1] = tmp;
			}
		}
	}
}

void choose(int b[])
{
	int tmp, a, j;

	for (i=0; i<10; i++)
	{
		
		a = i;
		for(j=i+1; j<10; j++)
		{
			if (num[a]>num[j])
				a=j;
		}
		if(a!=i)
		{
			tmp = num[i];
			num[i] = num[a];
			num[a] = tmp; 
		}

	}
}

int main(void)
{
	init ();
	printf("before sort:\n");
	show(num);

	bubble(num);
//	choose(num);

	printf("after sort: \n");
	show(num);

	return 0;
}
