#include <stdio.h>
#include <string.h>
#define N 16
char s[N];

void reverse(char s[])
{
	int l, r;
	char tmp;

	l = 0;
	r = strlen(s)-1;

	for (; l<r; l++,r--)
	{
		tmp=s[l];
		s[l]=s[r];
		s[r]=tmp;
	}
}
char *myitoa (int n, char *p)
{
	int c, sign, i=0;

	if((sign=n)<0)
		n = -n;
	
	do{
		c = n%10;
		s[i++] = c + '0';
	}while((n/=10)>0);

	if(sign < 0)
		s[i++]='-';
	s[i]='\0';

	reverse (s);

	printf("%s\n", s);
}

int main(void)
{
	int n;

	printf("please input a number: ");
	scanf("%d", &n);

	myitoa(n, s);

	return 0;
}
