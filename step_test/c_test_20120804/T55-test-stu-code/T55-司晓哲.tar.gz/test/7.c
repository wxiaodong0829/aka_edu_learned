#include <stdio.h>
typedef struct stud {
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
}stud;
void readrec(stud * students)
{
	int i;
	for (i = 0; i < 10; i++){
		printf("\n%10s : ", "ID");
		scanf("%d", &(students[i].id));
		printf("\n%10s : ", "Name");
		scanf("%s", students[i].name);
		printf("\n%10s : ", "S");
		scanf("%d %d %d %d", &students[i].s[0], &students[i].s[1], &students[i].s[2], &students[i].s[3]);
		students[i].ave = ( students[i].s[0] + students[i].s[1] + students[i].s[2] + students[i].s[3] )/4;
	}
}
void writerec(stud *students)
{
	int i;
	for (i = 0; i < 10; i++){
		printf("\n%10s : %10d", "ID", students[i].id);
		printf("\n%10s : %10s", "Name", students[i].name);
		printf("\n%10s : %5d %5d %5d %5d", "S", students[i].s[0], students[i].s[1], students[i].s[2], students[i].s[3]);
		printf("\n%10s : %5.2f", "Ave", students[i].ave);
	}
	printf("\n");
}
void main()
{
	stud students[10];
	readrec(students);
	writerec(students);
}

