#include <stdio.h>
void getrandint(int a[], int l, int r, int size)
{
	int i;
	srand(time(NULL));
	for (i = 0; i < size; i++)
		a[i] = rand() % (r - l + 1) + l;
}

void xsort(int a[], int size)
{
	int i;
	int tmp;
	if (size == 1)
		return;
	for (i = 1; i < size; i++)
		if (a[i] < a[0])
			tmp = a[i], a[i] = a[0], a[0] = tmp;
	xsort(&a[1], size - 1);
}
void print(int a[],int size)
{
	int i;
	for (i = 0; i < size; i++)
		printf("%5d", a[i]);
	printf("\n");
}
void main()
{
	int arr[5][5], i;
	getrandint((int *)arr, 0, 99, 25);
	for (i = 0; i < 5; i++)
		print(&arr[i], 5);
	printf("\n");
	for (i = 0; i < 5; i++)
		xsort(&arr[i], 5);
	for (i = 0; i < 5; i++)
		print(&arr[i], 5);
	printf("\n");

	xsort((int *)arr, 25);
	for (i = 0; i < 5; i++)
		print(&arr[i], 5);
	printf("\n");


}
