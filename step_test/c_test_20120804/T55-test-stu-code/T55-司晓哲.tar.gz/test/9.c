#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef char * va_list;
	
#define va_arg(ap, T) (*(T *)(((ap) += _Bnd(T, 3U)) - _Bnd(T, 3U)))
#define va_end(ap) (void)0
#define va_start(ap, A) (void)((ap) = (char *)&(A) + _Bnd(A, 3U))
#define _Bnd(X, bnd) (sizeof(X) + (bnd) & ~(bnd))


char *vstrcat(const char *first, ... )
{
	va_list ap;
	char * end;
	char * tmp;
	char * str1;
	char * str = (char *)malloc(strlen(first)+1);
	end = str;
	strcpy(str, first);
	va_start(ap, first);
	while (tmp = va_arg(ap, char *)) {
		str1 = (char *)malloc(strlen(tmp)+1+strlen(str)+1);
		strcpy(str1, str);
		free(str);
		end = str = str1;
		while(*end)++end;
		strcpy(end, tmp);
	}
	va_end(ap);
	return str;
}
void main()
{
	char * str;
	printf("%s\n", vstrcat("hello", " world", "si xiaozhe", " Magic", NULL));
}
