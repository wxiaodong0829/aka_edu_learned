#include <stdio.h>
void getrandint(int a[], int l, int r, int size)
{
	int i;
	srand(time(NULL));
	for (i = 0; i < size; i++)
		a[i] = rand() % (r - l + 1) + l;
}

void msort(int a[], int size)
{
	int f;
	int i, j, tmp;
	for (i = 0; i < size; i++) {
		f = 0;
		for (j = size-1; j > i; j--) {
			if (a[j]<a[j-1])
				tmp = a[j], a[j] = a[j-1], a[j-1] = tmp, f = 1;
		}
		if (f == 0) break;
	}
}
void xsort(int a[], int size)
{
	int i;
	int tmp;
	if (size == 1)
		return;
	for (i = 1; i < size; i++)
		if (a[i] < a[0])
			tmp = a[i], a[i] = a[0], a[0] = tmp;
	xsort(&a[1], size - 1);
}
void print(int a[],int size)
{
	int i;
	for (i = 0; i < size; i++)
		printf("%5d", a[i]);
	printf("\n");
}
void main()
{
	int a[10], i;
	getrandint(a, 10, 50, 10);
	print(a, 10);
	xsort(a, 10);
	print(a, 10);
	getrandint(a, 10, 50, 10);
	print(a, 10);
	msort(a, 10);
	print(a, 10);

}
