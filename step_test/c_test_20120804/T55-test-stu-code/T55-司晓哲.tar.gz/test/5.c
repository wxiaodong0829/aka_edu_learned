#include <stdio.h>
#include <string.h>
int compna(const void *a, const void *b)
{
	return isalpha(*(char *)b)-isalpha(*(char *)a);
}
char * fun(char *s)
{
	qsort(s, strlen(s), 1, compna);
	return s;
}
void main(int argc, char *argv[])
{
	char str[100];
	if (argc == 1) {
		printf("缺少命令行参数！");
		return;
	}
	printf("%s\n", argv[1]);
	strcpy(str, argv[1]);
	printf("%s\n", fun(str));
}
