#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void swap(int i, int j, char * s)
{
	char temp;
	temp = s[i];
	s[i] = s[j];
	s[j] = temp;
}
int reverse(char * s)
{
	int m=0,n=strlen(s)-1;
	while (n>m){
		swap(n--,m++,s);
	}
}
void dollars(char *dest, char const *src)
{
	char s[80];
	int i, j, m = 3;
	strcpy(s, src);
	reverse(s);
	for (i = 0, j = 0; s[i]; i++) {
		if (i == 2)
			dest[j++] = '.';
		else if ((i-2)%3==0)
			dest[j++] = ',';
		dest[j++] = s[i], m--;
	}
	if (m == 2) {
		dest[j++] = '0';
		dest[j++] = '.';
		dest[j++] = '0';
	} else if(m == 1){
		dest[j++] = '.';
		dest[j++] = '0';
	}
	dest[j++] = '$';
	dest[j] = '\0';
	reverse(dest);
}
void main()
{
	char src[80];
	char dest[100];
	while(1){
		scanf("%s", src);
		printf("src = %s\n", src);
		dollars(dest, src);
		printf("dest = %s\n", dest);
	}
}
