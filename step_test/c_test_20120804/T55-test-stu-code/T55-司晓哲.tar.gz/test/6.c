#include <stdio.h>
#include <string.h>

int reverse(char * s);
void myitoa(unsigned n, char * a,int base)
{
	int i=0, sign;
	if ((sign=n) < 0) n=-n;
	do {
		switch (n%base) {
			case 0: case 1: case 2:case 3:case 4:case 5:case 6:case 7:case 8:case 9: a[i++] = (n%base) + '0';break;
			case 10:case 11:case 12:case 13:case 14:case 15: a[i++] = (n%base) - 10 + 'a';break;
		}
	} while ((n/=base) > 0);
	if (sign < 0)
		a[i++]='-';
	a[i]='\0';
	reverse(a);
}
void swap(int i, int j, char * s)
{
	char temp;
	temp = s[i];
	s[i] = s[j];
	s[j] = temp;
}
int reverse(char * s)
{
	int m=0,n=strlen(s)-1;
	while (n>m){
		swap(n--,m++,s);
	}
}
void main()
{
	char i[20];
	int in;
	scanf("%d", &in);
	myitoa(in, i, 10);
	printf("%s\n", i);
}
