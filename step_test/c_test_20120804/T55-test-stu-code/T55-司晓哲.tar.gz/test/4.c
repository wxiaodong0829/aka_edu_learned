#include <stdio.h>
void movmax(char *str)
{
	char tmp, ch;
	char * max = str;
	char * s = str+1;
	while (ch = *s++)
		max = ch > *max ? s : max;
	tmp = *max;
	while (max-- != str)
		*(max+1) = *max;
	*str = tmp;
}
void main()
{
	char  str[] = "chyab";
	printf("%s\n", str);
	movmax(str);
	printf("%s\n", str);
}
