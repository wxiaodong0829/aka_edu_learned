#include <stdio.h>
int primes(int k)
{
	int i, j, n = 0;
	if (k<2) return 0;
	if (k==2) {printf("2\t");n++;return n;}
	if (k>=3) {
		printf("2\t");
		for (i=3; i<=k; i++) {
			for (j=2; j*j <= i; j++)
				if (i%j==0) break;
			if(j*j > i) {
				printf("%d\t", i);
				n++;
			}
		}
	}
	return n;
}
void main()
{
	int n;
	scanf("%d", &n);
	primes(n);
}
