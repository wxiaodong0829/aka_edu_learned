#include <stdio.h>
#include <string.h>
#define N 100
void reverse(char *s)
{
	char temp;
	int i, j = strlen(s) - 1;
	for (i=0; i <= j; i++,j--)
	{
		temp = s[i];
		s[i] = s[j];
		s[j] = temp;
	}
}

char *myitoa(int n, char *p)
{
	int i, sign;
	
	if ((sign=n) < 0)
		n = -n;
	i=0;
	do {
		p[i++] = n % 10 + '0';
	}
	while (n /= 10);
	if (sign < 0)
		p[i++] = '-';
	p[i] = '\0';
	reverse(p);
	return p;
}
int main(void)
{
	char s[N];
	int a = -123;

	printf("%s\n", myitoa(a, s));
	return 0;
}
