#include <stdio.h>
#define N 500

char *fun(char s[])
{
	char t[N], m[N];
	char *p = t;
	int i, j=0, k=0;

	for (i=0; s[i]; i++)
	{
		if ((s[i]>='a' && s[i]<='z') || (s[i]>='A' && s[i]<='Z'))
			t[j++] = s[i];
		else 
			m[k++] = s[i];
	}
	m[k] = '\0';
	k = 0;
	while ((t[j++] = m[k++]) != '\0');
	return p;

}
int main(void)
{
	char s[] = "asd123fgh543df";
	
	printf("%s\n", fun(s));
	return 0;
}
