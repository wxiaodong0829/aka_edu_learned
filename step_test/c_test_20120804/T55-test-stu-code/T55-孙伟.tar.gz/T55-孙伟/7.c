#include <stdio.h>
#include <stdlib.h>
#define N 100

typedef struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
} stu;
void writerec(stu student[])
{
	int i;

	for (i=0; i<10; i++)
		printf("%d %s %d %d %d %d %f\n",student[i].id, student[i].name, student[i].s[0],student[i].s[1], student[i].s[2], student[i].s[3],student[i].ave);
}
int readrec(stu student[])
{
	int flag=0, flag1=0;
	int i=0, j=0, k=0, t=0;
	int c;
	char b[N];

	student[0].ave = 0;
	while ((c = getchar()) != EOF)
	{
		if (c >='0' && c <= '9' && flag1 == 0)
		{student[i].id = c; flag = 1;}
		else if (c >= 'a' && c <= 'z')
		{
			student[i].name[j++] = c;
			if (c == ' ')
				student[i].name[j] = '\0';
		}
		else if(c >= '0' && c <= '9')
		{
			b[k++] = c;
			if (c == ' ')
			{
				k=0;
				student[i].s[t++] = atoi(b);
				student[i].ave +=student[i].s[t];
			}
		}	
		if (c == '\n')
				{
					++i; 
					flag1=0;
					student[i].ave = 0;
				}
	}
	return flag = 1;	
}
int main(void)
{
	stu student[10];
	int flag=0;	
	while ((flag = readrec(student)) == 1)
		writerec(student);
	return 0;
}
