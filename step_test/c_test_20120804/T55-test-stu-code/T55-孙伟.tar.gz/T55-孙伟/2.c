#include <stdio.h>

void mysort0(int a[])
{
	int i, j;
	int temp;

	for (i=0; i<10; i++)
		for (j=0; j<10-i; j++)
			if (a[j] > a[j+1])
			{
				temp = a[j];
				a[j] = a[j+1];
				a[j+1] = temp;
			}
	for (i=0; i<10; i++)
		printf("%d ", a[i]);

}
void mysort(int a[])
{
	int i, j;
	int temp;

	for (i=0; i<10; i++)
		for (j=i+1; j<10; j++)
		if (a[i] > a[j])
		{
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	for (i=0; i<10; i++)
	printf("%d ", a[i]);
	printf("\n");
}
int main(void)
{
	int num[10];
	int i;
	srand(time(NULL));
	for (i=0; i<10; i++)
		num[i] = rand()%100;
	mysort0(num);
	printf("\n");
	printf("-----------------------------\n");
	mysort(num);
	return 0;
}
