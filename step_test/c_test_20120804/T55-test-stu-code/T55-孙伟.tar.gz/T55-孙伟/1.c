#include <stdio.h>

main(void)
{
	int n;
	int i, j, k=2;

	scanf("%d", &n);
	printf("2 3 ");
	for (i=0; i<n; i++)
		for (j=2; j*j<i; j++)
			if (i%j ==0)
				break;
			else if((j+1)*(j+1)>i)
			{
				printf("%d ", i);
				k++;
				if(k%5==0)
					printf("\n");
			}
			else 
				continue;
	printf("\n");
}
