#include <stdio.h>

char * str(char s[])
{
	int i, k, j = 1;
	char max, temp, temp0;

	max = s[0];
	temp = s[0];
	for (i=0; s[i]; i++)
		if (max < s[i])
		{
			max = s[i];
			k = i;
		}
	for (i=1; i<=k; i++)
	{
		temp0= s[i];
		if (j==1)
		{s[j] = temp; j++;}
	    else	s[j++] = temp;
		temp = temp0;
	}
	s[0] = max;
	return s;
}

int main(void)
{
	char s[] = "abclefgchyab";

	printf("%s\n", str(s));

	return 0;
}
