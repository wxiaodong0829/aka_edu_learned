#include <stdio.h>

void mysort(int s[], int n)
{
	int i,j;
	int temp;
	for (i=0; i<n; i++)
		for (j=i+1; j<n; j++)
			if (s[i] > s[j])
			{
				temp = s[i];
				s[i] = s[j];
				s[j] = temp;
			}
	
}
int main(void)
{
	int arr[5][5];
	int i, j;
	srand(time(NULL));
	for (i=0; i<5; i++)
		for (j=0; j<5; j++)
			arr[i][j] = rand()%200;

	for (i=0; i<5; i++)
		mysort(arr[i], 5);
	for (i=0; i<5; i++)
		for (j=0; j<5; j++)
		{			
			printf("%d ", arr[i][j]);
			if (j==4)
				printf("\n");
		}
	printf("\n");
		mysort(arr[0], 25);
	for (i=0; i<25; i++)
		{			
			printf("%d ", arr[0][i]);
			if ( (i!=0) &&(i%4==0))
				printf("\n");
		}
	printf("\n");
	return 0;

}

