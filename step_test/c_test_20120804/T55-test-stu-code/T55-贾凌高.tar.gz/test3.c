#include <stdio.h>

void init_array(int num[][5], int size_m, int size_n);
void show_array(int num[][5], int size_m, int size_n);
void select_sort(int num[], int size);

int main()
{
	int i;
	int arr[5][5];

	init_array(arr, 5, 5);
	show_array(arr, 5, 5);

	for(i = 0; i < 5; i++)//实现每行元素的排序
	{
		select_sort(arr[i], 5);
	}
	show_array(arr, 5, 5);

	select_sort(arr[0], 25);//实现所有元素的排序
	show_array(arr, 5, 5);

	return 0;
}

void init_array(int num[][5], int size_m, int size_n)
{
	int i, j;
	for(i = 0; i < size_m; i++)
	{
		for(j = 0; j < size_n; j++)
			num[i][j] = (rand()%100);
	}
}

void show_array(int num[][5], int size_m, int size_n)
{
	int i, j;
	for(i = 0; i < size_m; i++)
	{
		for(j = 0; j < size_n; j++)
			printf("%d  ",num[i][j]);
		printf("\n");
	}
	printf("\n");
}

void select_sort(int num[], int size)
{
	int min, tmp;
	int i, j;
	for(i = 0; i < size-1; i++)
	{
		min = i;
		for(j = i+1; j < size; j++)
		{
			if(num[min] > num[j])
				min = j;
		}
		if(i != min)
		{
			tmp = num[i];
			num[i] = num[min];
			num[min] = tmp;
		}
	}
}
