#include <stdio.h>
#include <math.h>

int main(void)
{
	int p, m, i, j;
	scanf("%d", &p);
	for(i = 2; i <= p; i++)
	{
		m = sqrt(i);
		for(j = 2; j <= m; j++)
			if(i%j == 0)
				break;
		if(j > m)
			printf("%d\n", i);
	}
}
