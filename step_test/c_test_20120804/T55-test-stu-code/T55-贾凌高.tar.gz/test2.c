#include <stdio.h>

void init_array(int num[], int size);//赋初值
void show_array(int num[], int size);//打印
void bubble_sort(int num[], int size);//冒泡排序
void select_sort(int num[], int size);//选择排序


int main(void)
{
	int num[10];
	srand(time(NULL));

	init_array(num, 10);
	show_array(num, 10);
	printf("冒泡排序\n");
	bubble_sort(num, 10);
	show_array(num, 10);

	printf("\n");
	init_array(num, 10);
	show_array(num, 10);
	printf("选择排序\n");
	select_sort(num, 10);
	show_array(num, 10);

	return 0;
}

void init_array(int num[], int size)
{
	int i;
	for(i = 0; i < size; i++)
	{
		num[i] = (rand()%100);
	}
}

void show_array(int num[], int size)
{
	int i;
	for(i = 0; i < size; i++)
	{
		printf("%d\n",num[i]);
	}
}

void bubble_sort(int num[], int size)
{
	int i, j;
	int tmp, flag;
	for(i = 0, flag = 0; i < size; i++, flag = 0)
	{
		for(j = 1; j < size - i; j++)
		{
			if(num[j-1] > num[j])
			{
				tmp = num[j-1];
				num[j-1] = num[j];
				num[j] = tmp;
				flag = 1;
			}
		}
		if(flag == 0)
			break;
	}
}

void select_sort(int num[], int size)
{
	int min, tmp;
	int i, j;
	for(i = 0; i < size-1; i++)
	{
		min = i;
		for(j = i+1; j < size; j++)
		{
			if(num[min] > num[j])
				min = j;
		}
		if(i != min)
		{
			tmp = num[i];
			num[i] = num[min];
			num[min] = tmp;
		}
	}
}
