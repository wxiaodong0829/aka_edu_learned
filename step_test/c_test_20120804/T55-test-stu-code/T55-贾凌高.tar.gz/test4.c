#include <stdio.h>
#include <string.h>

void bigest_to_first(char str[]);

int main(void)
{
	char str[] = "abcdefgacb";
	printf("%s\n", str);
	bigest_to_first(str);
	printf("%s\n", str);
}

void bigest_to_first(char str[])
{
	char bigest = str[0];
	int i, j;

	for(i = 0; str[i] != '\0'; i++)//找到最大字符位置
		if(bigest < str[i])
			bigest = str[i], j = i;

	for(i = 0; i < j; i++)//移动字符
		str[j-i] = str[j-i-1];

	str[0] = bigest;
}
