#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdarg.h>

char *vstrcat(const char *first, ...);

int main(void)
{
	char *a = "hahahaha";
	char *b;

	b = vstrcat(a, "12345", "houhouhouhou", NULL);

	printf("%s\n", b);
}

char *vstrcat(const char *first, ...)
{
	va_list ap;
	char *s, *p;
	int size = strlen(first);
	int a = 0;

	va_start(ap, first);
	s = va_arg(ap, char *);
	while( s != NULL)//先确定要分配的总大小
	{
		size += strlen(s);
		s = va_arg(ap, char *);
	}
	va_end(ap);

	p = malloc(size+1);//分配
	strcpy(p, first);

	va_start(ap, first);
	s = va_arg(ap, char *);
	while(s != NULL)//将所有字符串拷贝到分配好的空间
	{
		a = strlen(p);
		strcpy(p+a, s);
		s = va_arg(ap, char *);
	}
	va_end(ap);

	return p;
}
