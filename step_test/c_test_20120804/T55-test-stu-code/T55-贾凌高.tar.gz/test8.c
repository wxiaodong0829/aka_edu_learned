#include<stdio.h>
#include<string.h>

#define N 20

void dollars(char *dest, char const *src);
void reverse(char s[], int i, int j);

int main(void)
{
	char dest[N];
	char src[N];
	scanf("%s", src);
	dollars(dest,src);
	printf("%s\n", dest);

	return 0;
}

void dollars(char *dest, char const *src)
{
	int i, j, m;
	int len, len_left;

	len = strlen(src);
	len_left = len -2;
	m = (len_left)%3;

	for(i = 0, j = 0; i < len || i < 3; i++, j++)
	{//从后往前输入dest
		if((i)%3 == 2)//每三个数字前有一个分隔符，第一个符号即i==2时为'.'
		{		
			if(i == 2)
				dest[j] = '.';
			else
				dest[j] = ',';
			j++;
		}
		if(len-i > 0)
			dest[j] = src[len-i-1];
		else//数字少于三个，用'0'补齐缺少的
			dest[j] = '0';
	}
	dest[j++] = '$';
	dest[j] = '\0';

	reverse(dest, 0, strlen(dest)-1);//将dest倒置
}

void reverse(char s[], int i, int j)
{
	char tmp;
	if(i <= j)
	{
		tmp = s[i];
		s[i] = s[j];
		s[j] = tmp;
		reverse(s, ++i, --j);
	}
}
