#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define N 16



char *myitoa(int n, char *p);
void reverse(char s[]);

int main(void)
{
	int i;
	char p[N];

	scanf("%d", &i);

	myitoa(i, p);
	printf("%s\n", p);

	return 0;
}

void reverse(char s[])
{
	int i, j, tmp;
	for(i = 0, j = strlen(s)-1; i < j; i++, j--)
		tmp = s[i], s[i] = s[j], s[j]= tmp;
}

char *myitoa(int n, char *p)
{
	int i = 0, sign;
	if((sign=n) < 0)
		n = -n;
	do
	{
		p[i++] = n % 10 + '0';
	}
	while((n/=10) > 0);
	if(sign < 0)
	{
		p[i++] = '-';
	}
	p[i] = '\0';
	reverse(p);

	return p;
}
