#include <stdio.h>

#define N 10

struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
};

void readrec(struct stud *S);
void writerec(struct stud *S);

int main(void)
{
	struct stud S[N];
	readrec(S);
	writerec(S);

	return 0;
}

void readrec(struct stud *S)
{
	int i, j;
	for(i = 0; i < N; i++)
		scanf("%hu%s%d%d%d%d", &S[i].id, S[i].name, &S[i].s[0],\
				&S[i].s[1], &S[i].s[2], &S[i].s[3]);
		S[i].ave = (S[i].s[0]+S[i].s[1]+S[i].s[2]+S[i].s[3])/4.0;
}

void writerec(struct stud *S)
{
	int i, j;
	for(i = 0; i < N; i++)
		printf("ID:%hu\nNAME:%s\nS:%d %d %d %d\nAVE:%f\n",\
				S[i].id, S[i].name, S[i].s[0], \
				S[i].s[1], S[i].s[2], S[i].s[3], S[i].ave);
}
