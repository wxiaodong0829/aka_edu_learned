#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define swap(t, x, y) {t tmp=x;x=y;y=tmp;}

#define N 5

int arr[N][N];

void init()
{
	int i, j = 0;
	srand(time(NULL));

	for(i = 0; i < N; i++)
	{
		for(j = 0; j < N; j++)
			arr[i][j] = rand()%100;
	}
}

int show()
{
	int i, j;

	for(i = 0; i < N; i++)
	{
		for(j = 0; j < N; j++)
		{
			printf("%3d", arr[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}

int sort(int s[], int n)
{
	int i, j;
	int tmp;

	for(i = 0; i < n; i++)
	{
		tmp = i;
		for(j = i + 1; j < n; j++)
		{
			if(s[tmp] > s[j])
				tmp = j;
		}
		if(tmp != i)
			swap(int, s[i], s[tmp]);
	}

	return 0;
}

int main()
{
	int i, j;

	init();
	show();

	printf("\n");


	for(i = 0; i < N; i++)
		sort(arr[i], N);
	show();
	printf("\n");

	sort(arr, N*N);	
	show();
}
