#include <stdio.h>
#include <string.h>
#define swap(t, x, y){t tmp=x;x=y;y=tmp;}

int max_char(char s[])
{
	int i;
	int len, count = 0;
	char tmp, max = s[0];

	len = strlen(s);

	for(i = 0; i < len; i++)
	{
		if(max < s[i])
		{
			max = s[i];
			count = i;
		}
	}

	if(count != 0)
	{
		tmp = s[count];

		for(i = count; i >= 0 ; i--)
			s[i] = s[i-1];
		s[0] = tmp;
	}
	printf("%s\n", s);

	return 0;
}

int main()
{
	max_char("chyab");

	return 0;
}

