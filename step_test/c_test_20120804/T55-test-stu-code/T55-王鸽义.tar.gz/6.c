#include <stdio.h>
#include <string.h>
#define N 10

void reverse(char s[])
{
	int i, j, tmp;
	int len = strlen(s);

	for(i = 0, j = len-1; i < j; i++, j--)
	{
		tmp = s[i];
		s[i] = s[j];
		s[j] = tmp;
	}
}

char *myitoa(int n, char *p)
{
	int i = 0;
	int flag;

	if((flag = n) < 0) n = -n;

	do{
		p[i++] = (n % 10) + '0';
		n /= 10;
	}while(n > 0);

	if(flag < 0) p[i++] = '-';
	p[i++] = '\0';
	reverse(p);
	
	printf("%s\n", p);

	return p;
}

int main()
{
	char p[N];

	myitoa(-123456, p);

	return 0;
}
