#include <stdio.h>

int main()
{
	int n;
	int i, j, flag;

	scanf("%d", &n);

	if(n < 2)
		printf("No primes\n");
	else
	{
		printf("      2");

		for(i = 3; i <= n; i+=2) {
			flag = 1;
			for(j = 2; j*j <= i; j++) {
				if(i%j == 0) {
					flag = 0;
					continue;
				}
			}
			if(flag == 1)
				printf("%4d", i);
		}	
	}

	printf("\n");
	return 0;
}
