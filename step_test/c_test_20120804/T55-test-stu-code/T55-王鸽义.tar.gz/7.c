#include <stdio.h>
#include <stdlib.h>
#define N 3

struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
};

int readrec(struct stud p[])
{
	int i, j;

	for(i = 0; i < 3; i++)
	{
		scanf("%d\t%s\t", &p[i].id, p[i].name);
		for(j = 0; j < 4; j++)
			scanf("%d", &p.s[j]);
	}	

	for(i = 0; i < N; i++)
	{
		for(j = 0; j < 4; j++)
			p[i].s += p[i].s[j];
		p[i].ave = (p[i].s)/4;
	}

	return 0;
}

int main()
{
	struct stud a[N];

	printf("id\tname\ts[0]\ts[1]\ts[2]\ts[3]\n");

	readrec(a);

	return 0;
}
