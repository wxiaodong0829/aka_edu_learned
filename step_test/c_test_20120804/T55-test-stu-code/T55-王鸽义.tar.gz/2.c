#include <stdio.h>
#include <time.h>
#define N 10 

#define swap(t, x, y) {t tmp=x;x=y;y=tmp;}

int num[N];

void init()
{
	int i = 0;

	srand(time(NULL));

	for(i = 0; i < N; i++)
		num[i] = rand()%100;
}

void show()
{
	int i;

	for(i = 0; i < N; i++)
		printf("%3d", num[i]);
	printf("\n");
}

int sort1()
{
	int i, j;

	for(i = 0; i < N; i++)
	{
		for(j = 0; j < N-1; j++)	
		{
			if(num[j] > num[j+1])
				swap(int, num[j], num[j+1]);
		}
	}

	return 0;
}

int sort2()
{
	int i, j;
	int tmp;

	for(i = 0; i < N; i++)
	{
		tmp = i;
		for(j = i + 1; j < N; j++)
		{
			if(num[tmp] > num[j])
			{
				tmp = j;
			}

		}
		if(tmp != i)
			swap(int, num[i], num[tmp]);
	}

	return 0;
}

int main()
{
	int i;

	init();
	show();

	sort1();
	show();

	sort2();
	show();

	return 0;
}
