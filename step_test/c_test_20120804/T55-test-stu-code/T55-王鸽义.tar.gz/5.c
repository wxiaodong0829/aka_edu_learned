#include <stdio.h>
#include <string.h>

int main()
{
	char s[] = "asd123fgh543df";
	int str = strlen(s);
	int i, j, end;
	char tmp;

	for(i=end=(str-1); i >= 0; i--)
	{
		if(isdigit(s[i]))
		{
			tmp = s[i];

			for(j=i; i<end; i++)
				s[i] = s[i+1];

			s[end--] = tmp;
		}
	}

	printf("%s\n", s);

	return 0;

}
