#include <stdio.h>
int main(void)
{
	int arr[5][5];
	int i,j;
	for(i=0;i<5;i++)
		for(j=0;j<5;j++)
//		scanf("%d",&arr[i][j]);
			arr[i][j]=rand()%100;
	printf("****************\n");
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
			printf("%d ",arr[i][j]);
	printf("\n");
	}
	printf("****************\n");
	for(i=0;i<5;i++)
	{
		for(j=0;j<4;j++)
		{
			int n=j,tmp,m;
			for(m=j+1;m<5;m++)
				if(arr[i][m]<arr[i][n])
					n=m;
			if(n!=j)
			{
				tmp=arr[i][j];
				arr[i][j]=arr[i][n];
				arr[i][n]=tmp;

			}

		}
	}
	for(i=0;i<5;i++)
	{
		for(j=0;j<5;j++)
			printf("%d ",arr[i][j]);
	printf("\n");
	}
	return 0;

}
