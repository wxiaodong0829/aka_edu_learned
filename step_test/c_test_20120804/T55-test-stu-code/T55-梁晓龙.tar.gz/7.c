#include <stdio.h>
struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
};
void  readrec(struct stud)
{
	int i,j;
	for(i=0;i<10;i++)
	{
	//	scanf("%s",&stud -> id);
		scanf("%s",&(stud -> name[i]));
	//	for(j=0;j<4;j++)
	//	scanf("%d",&stud -> s[j]);
	}
/*	for(i=0;i<4;i++)
	{
		int sum=0;
		sum+=s[i];
	}
	*/

}
int writerec (struct stud)
{
	int i;
	for(i=0;i<10;i++)
	{
	//	printf("%s",stud ->id);
		printf("%s",stud ->name[i]);
	//	printf("%s",stud ->id);
	}
	return 0;
}
int main()
{
	readrec(struct stud);
	writerec(struct stud);
	return 0;
}
