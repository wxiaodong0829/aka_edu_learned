#include <stdio.h>
#define N 1000
int main()
{
     char max,*p,s[N]; int i=0;
	 scanf("%s",s);
     max=s[i];
     while(s[i]!='\0')
     {
         if(max<=s[i])
         {
             max=s[i];
             p=s+i;
         }
         i++;
     }
     while(p>s)
     {
         *p=*(p-1);
         p--;
     }
     p[0]=max;
  
printf("%s\n",s);
return 0;
}

 


   
   



