#include <stdio.h>
int main()
{
	int num[10];
//	printf("input 10 num:");
	int i,j;
	for(i=0;i<10;i++)
//		scanf("%d",&num[i]);
		num[i]=rand()%100;
	for(i=0;i<10;i++)
		printf("%d ",num[i]);
	printf("\n");
#if 0
	for(i=0;i<10;i++)
	{
		int tmp,flag;
		for(j=8;j>=i;j--)
			if(num[j+1]<num[j])
			{
				tmp = num[j+1];
				num[j+1]=num[j];
				num[j]=tmp;
				flag = 1;
			}
		if(!flag)
			break;
	}
#endif
	for(i=0;i<9;i++)
	{
		int k=i,tmp;
		for(j=i+1;j<10;j++)
			if(num[j]<num[k])
				k=j;
		if(k!=i)
		{
			tmp=num[i];
			num[i]=num[k];
			num[k]=tmp;
			
		}
	}
	for(i=0;i<10;i++)
		printf("%d ",num[i]);
	printf("\n");
	return 0;

}
