#include <stdio.h>
#include <string.h>
#include <ctype.h>
char *fun (char s[])
{
	int i, j, end;
	char tmp;
    for(i = end = strlen(s) - 1; i >= 0; i--){
        if(isdigit(s[i])){
            tmp = s[i];
            for(j = i; i < end; i++)
                s[i] = s[i + 1];

            s[end--] = tmp;
        }
    }
return s;
}
int main(void)
{
	char s[100];
    printf("Input s:");
    scanf("%s", s);
   fun(s);
   printf("%s\n",s);
    return 0;
}

