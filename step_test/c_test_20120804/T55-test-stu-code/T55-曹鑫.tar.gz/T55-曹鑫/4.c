#include<stdio.h>
#include<string.h>

#define N 100

char * upgate(char *, int);

int main()
{
	char s[N];
	char *c;
	scanf("%s",s);
	printf("the start sort %s\n",s);
	
	c = upgate(s, strlen(s));
	printf("the end sort %s\n",c);

	return 0;
}

char * upgate(char s[], int n)
{
	int i;
static	int	j = 0;
	static	char t[N];
	
#if 1
	for(i = 0; i < n; i++)
		if( s[i] >= 'a'&& s[i] <= 'z')
		t[j++] = s[i];
#endif

#if 1
	for(i = 0; i < n; i++)
		if( s[i] < 'a' && s[i] > 'z')
			t[j++] = s[i];
			t[j] = '\0';	
#endif
			return t;
}
