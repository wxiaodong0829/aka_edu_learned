#include<stdio.h>


#define N  10

typedef struct stud{ int id; char name[10]; int s[4]; double ave;} people;
people student[N];

void init(int n)
{	
	int i;
	student[n].ave = 0.0;
	scanf("%d",&(student[n].id));
	scanf("%s",student[n].name);
	for(i = 0; i < 4; i++)
	{
	scanf("%d", &(student[n].s[i]));
	student[n].ave = student[n].ave+student[n].s[i];
	}
	student[n].ave = student[n].ave/4.0;

}
void show(int n)
{	
	int i ;
	printf("%10d    ", student[n].id);
	printf("%s      ", student[n].name);
	for(i = 0; i < 4; i++)
		printf("%4d", student[n].s[i]);
	printf("%f\n", student[n].ave);
}



int main()
{
	int i;
	for(i = 0; i < N; i++)
	{
	init(i);
	show(i);
	}
	return 0;


}

