#include<stdio.h>
#include<string.h>

#define N 100
#define SWAP(t,x,y)    ((t) = (x), (x) = (y), (y) = (t))

char *itoa(int, char *);
void reserve(char *, int);


int main(void)
{	
	char s[N], *c;	
	c = itoa(20, s);
	reserve(c, strlen(c) );
	
	printf("%s\n",c);

	return 0;
}

char *itoa(int n, char *s)
{
	int i = 0;
	while(n)
	{
		s[i++] =n%10 + '0';
		n = n/10;
	}
	s[i] = '\0';
	return s;
}
void reserve(char *p, int n)
{
	int i = 0, j = n-1, t;
	while(i<j){
	SWAP( t, *(p+i), *(p+j));
	i++;
	j--;
	}
}
