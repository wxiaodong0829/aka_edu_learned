#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define N 5
#define M 5
#define SWAP(t, x, y)   ( (t) = (x), (x) = (y), (y) = (t) )

void init(int *);
void xzsort(int *, int);
void show(int *,int);

int main(void)
{
	int i;
	int a[N][M];
	
	for( i = 0; i < N; ++i)
	{
		init(a+i);
		xzsort(a+i,N);
		show(a+i, N);
	}

		xzsort(a, N*M);
		show(a, N*M);
	 
		return 0;



}

void show(int *p, int n)
{

	int i = 0;
			
	for( ; i < n; i++)
	printf("%3d", *(p+i));
	putchar('\n');
}


void init(int *p)
{
		
	int i;
			
	srand(time(NULL));
	for(i = 0; i < N; i++)
	*(p+i) = rand()%100;
}


void xzsort(int *p, int n)
{

	int i, j, t;

	for(i = 0; i < n; i++)
	for(j = i; j < n; j++)
	if(*(p+i) > *(p+j))
	SWAP(t, *(p+j), *(p+i));
}

















