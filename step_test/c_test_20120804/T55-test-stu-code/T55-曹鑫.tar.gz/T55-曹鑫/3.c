#include<stdio.h>

#define N  100

char fmac(char *);

int main(void)
{	
	char c;
	char s[N];

	scanf("%s",s);
	c = fmac(s);
	printf("%s\n",s);
	printf("%c\n",c);
	
	return 0;
}

char fmac(char *p)
{
	int i, t;
	char max = *p;

	for(i = 0; *(p+i) ; i++)
	if(*(p+i) > max) {
		max = *(p+i);
		t  = i;}	
	for(i = t; i > 0; i--)
		*(p+i) = *(p+i-1);
		*p = max;
	
	return max;

}
