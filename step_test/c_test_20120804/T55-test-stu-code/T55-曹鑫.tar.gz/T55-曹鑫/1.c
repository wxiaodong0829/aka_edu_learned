#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define N  10
#define SWAP(t, x, y)   ( (t) = (x), (x) = (y), (y) = (t) )

void init(int *);
void paosort(int *);
void xzsort(int *);
void show(int*);

int main(void)
{
	int a[N];

	init(a);
	show(a);
	paosort(a);
	show(a);
	xzsort(a);
	show(a);
	
	return 0;
}
void show(int *p)
{
	int i = 0;
	
	for( ; i < N; i++)
		printf("%3d", *(p+i));
	putchar('\n');
}


void init(int *p)
{	
	int i;
	
	srand(time(NULL));
	for(i = 0; i < N; i++)
		*(p+i) = rand()%100;
}

void paosort( int *p)
{
	int i, j, t;
	for(j = 0; j < N; j++)
	for(i = 0; i < N-j; i++)
		if(*(p+i) > *(p+i+1)) 
			SWAP(t, *(p+i), *(p+i+1));
}


void xzsort(int *p)
{
	int i, j, t;

	for(i = 0; i < N; i++)
		for(j = i; j < N; j++)
			if(*(p+i) > *(p+j))
				SWAP(t, *(p+j), *(p+i));
}








