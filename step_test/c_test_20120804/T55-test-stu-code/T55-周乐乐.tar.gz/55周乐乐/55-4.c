#include <stdio.h>
#include <string.h>
void move_char(char *s, int n)
{
	int i;
	char ch = s[n];

	for (i = n; i > 0; i--)
		s[i] = s[i-1];
	s[0] = ch;
}
void max_char(char *s)
{
	char ch = s[0];
	int n, i = 0;
	while(s[i++]) {
		if((int)ch< (int)s[i]) { 
			ch = s[i];
			n = i;
		}
	}
	move_char(s, n);
}
int main(void)
{
	char a[] = "liytrrAcse";
	max_char(a);
	puts(a);
	return 0;
}
