#include <stdio.h>
#include <time.h>
#define N 5

void init(int (*s)[N])
{
	int i, j;
	srand(time(NULL));
	for (i = 0; i < N; i++)
		for (j = 0; j < N; j++)
			s[i][j] = rand()%100;	
}
void show(int (*s)[N])
{
	int i, j;
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++)
			printf("%d\t", s[i][j]);		
		printf("\n");		
	}
	printf("\n");		

}
void swap(int (*s)[N], int i, int j, int m)
{
	int tmp;
	tmp = s[m][j], s[m][j] = s[m][i], s[m][i] = tmp;
}
void line_sort(int (*s)[N], int m)
{
	int i, j, max;
		for (i = 0; i < N-1; i++) {
			max = i;
			for (j = i+1; j < N; j++)
				if (s[m][max] < s[m][j])
					max = j;
			swap(s, i, max, m);
		}
}
#if 0
void select_move(int (*s)[N], int i, int j)
{
	int tmp = s[j/5][j%5], m, t = N*N;
#if 0
	for (m = i; m < j; m++) 
		for (n = j; n > i; n--)
#endif
	for (m = j; m < i; m--) 
			s[m/5][m%5] = s[(m-1)/5][(m-1)%5];
	s[i/5][i%5] = tmp;	
}
void select_sort(int (*s)[N])
{
	int i, j, n = N*N, max;

	for (i = 0; i < n; i++) {
			max = s[i/5][i%5];
		for (j = i+1; j < n; j++) {
				if (max < s[j/5][j%5])
					select_move(s, i, j);
		}
	}
}
#endif
int main(void)
{
	int arr[N][N], i;
	init(arr);
	show(arr);
#if 1
	for (i = 0; i < N; i++)
		line_sort(arr, i);
	show(arr);
#endif
	return 0;
}
