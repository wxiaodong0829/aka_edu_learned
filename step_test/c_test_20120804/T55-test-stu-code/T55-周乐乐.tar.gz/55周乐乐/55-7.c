#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 3
#define M 4

struct stud{
	unsigned short id;
	char name[10];
	int s[M];
	double ave;
	struct stud *next;
};
typedef struct stud *student;

student NODE(unsigned short id, char *name, int *s, student next)
{
	double sum = 0.0;
	student p = malloc(sizeof(struct stud));
	if (p == NULL) {
		printf("Attention: there is not enough memory!\n");
		return NULL;
	}
	p->id = id;
	strcpy(p->name, name);
	p->s[0] = s[0];
	p->s[1] = s[1];
	p->s[2] = s[2];
	p->s[3] = s[3];
	
	sum = s[0] + s[1] + s[2] + s[3];
	p->ave = sum/M;
	p->next = next;
//	p = p->next;

	return p;
}
student readrec(student head)
{
	student p = NULL;
	int s[M];
	unsigned short id;
	char name[10];
	int n = 0;
	 while(n++ < N) {
		printf("please input:");
		scanf("%d %s %d %d %d %d", &id, name, &s[0], &s[1], &s[2], &s[3]);
		p = NODE(id, name, s, p);	
	}

	 return p;
}
void writerec(student head)
{
	student p = head->next;

	while(p != NULL) {
		printf("%d\t%s\t%d\t%d\t%d\t%d\t%lf\n", p->id, p->name, p->s[0], p->s[1], p->s[2], p->s[3], p->ave);
		printf("\n");
		p = p->next;
	}
}
int main(void)
{
	student head = malloc(sizeof *head);
	if (head == NULL) {
		printf("Attention: there is not enough memory!\n");
		return -1;
	}
	head->next = NULL;
	head->next = readrec(head);
	writerec(head);

	return 0;
}
