#include <stdio.h>
#include <string.h>
#define N 512

void swap(char *p, int i, int j)
{
	char tmp;
	tmp = p[i], p[i] = p[j], p[j] = tmp;
}
void reverse(char *p)
{
	int i,j = strlen(p)-1;
	for (i = 0; i < j; i++, j--)
		swap(p, i, j);
}
char *myitoa(unsigned n, char *p)
{
	int sign = n, i = 0;	
	
	if (sign < 0) n = -n;
	do {
		p[i++] = n%10 + '0';
	}while(n/=10);	

	if (sign < 0) p[i++] = '-';
	p[i] = '\0';

	reverse(p);

	return p;
}
int main(void)
{
	char p[N];
	unsigned n = 456381;
	myitoa(n, p);
	puts(p);
	return 0;
}
