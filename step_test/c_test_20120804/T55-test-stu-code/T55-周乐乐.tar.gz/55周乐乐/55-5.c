#include <stdio.h>
#define N 32
void swap(char *s, int i, int j)
{
	char tmp;
	tmp = s[i], s[i] = s[j], s[j] = tmp;
}
void move_char(char *s, int i)
{
	int j = i;
	while(s[++j]) {
		if (isalpha(s[j]))
			swap(s, i, j);
	}
}
int main(void)
{
	int i= 0, n;
	char s[N] = "sadd123effd345cd";
	do {
		if (!isalpha(s[i])) {
			n = i;
			move_char(s, i);
		}
	}while(s[++i]);
	puts(s);
	printf("\n");
	
	return 0;
}

