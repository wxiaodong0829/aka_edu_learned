#include <stdio.h>
#define N 100
void init(int *s, int n)
{
	int i;
	for (i = 1; i< n; i++)
		s[i] = i;
}
void prime(int *s, int m)
{
	int i, j;
	printf("2\t");
	for (i = 3; i <m; i++) {
		for (j = 2; j*j < i; j++)
			if (i%j == 0) break;
		if (i%j != 0) printf("%d\t", i);
	}
	printf("\n");
}
int main(void)
{
	int s[N], m;	
	scanf("%d", &m);

	init(s, m);
	printf("\n");

	prime(s, m);

	return 0;
}
