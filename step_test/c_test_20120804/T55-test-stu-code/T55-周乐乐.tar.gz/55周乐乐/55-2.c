#include <stdio.h>
#include <time.h>
#define N 10
//#define PRINT(x) printf(#x" = ")
void init(int *s)
{
	int i = 0;
	srand(time(NULL));
	do {
		s[i] = rand()%100;	
	}while(++i < N);
}
void show(int *s)
{
	int i;
	for (i = 0; i < N; i++)
		printf("%d\t", s[i]);		
	printf("\n");		
	
}
void swap(int *s, int i, int j)
{
	int tmp;
	tmp = s[i], s[i] = s[j], s[j] = tmp;
}
void bubble_sort(int *s)
{
	int i, j;
	for (i = 0; i < N-1; i++)
		for (j = i; j < N; j++)
			if (s[i] > s[j])
				swap(s, i, j);
}
/*void select_move(int *s, int i, int j)
{
	int tmp = s[j], m;
	for (m = j; m > i; m--)
		s[m] = s[m-1];
	s[i] = tmp;	
}*/
void select_sort(int *s)
{
	int i, j, max;
	for (i = 0; i < N-1; i++) {
		max = i;
		for (j = i; j < N; j++)
			if (s[max] < s[j])
				max = j;
		if (max != i)
			swap(s, i, max);
	}
}
int main(void)
{
	int num[N];
	init(num);
	show(num);
	bubble_sort(num);
	show(num);
	select_sort(num);
	show(num);
	return 0;
}
