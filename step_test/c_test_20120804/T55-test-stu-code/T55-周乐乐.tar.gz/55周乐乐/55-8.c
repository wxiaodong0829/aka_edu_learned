#include <stdio.h>
#include <string.h>
#define N 50
void swap(char *p, int i, int j)
{
	char tmp;
	tmp = p[i], p[i] = p[j], p[j] = tmp;
}
void reverse(char *p)
{
	int i,j = strlen(p)-1;
	for (i = 0; i < j; i++, j--)
		swap(p, i, j);
}
void dollars(char *m, char *s)
{
	int len = strlen(s), i, j;
	for (i = 0,j = 0; i< len; i++) {
		m[j++] = s[len-1-i];
		if (i == 1 && (len -1) != 1) m[j++] = '.';
		if ((i-2)%3==2 && (len-1)!= i) m[j++] = ',';
		if (i == len-1)	m[j++] = '$';
	}
	m[j] = '\0'; 
	reverse(m);
}
int main(void)
{
	char s[N] = "1253423";
	char t[] = "23";
	char r[] = "23456";
	char m[N];
	dollars(m, s);
	puts(m);
	dollars(m, t);
	puts(m);
	dollars(m, r);
	puts(m);
	printf("\n");
	return 0;
}
