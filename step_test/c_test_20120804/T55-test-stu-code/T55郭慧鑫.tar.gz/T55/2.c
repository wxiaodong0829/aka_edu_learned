#include <stdio.h>
#include <time.h>
#define N 10
void init(int num[])
{
	int i;
	srand(time(NULL));
	for(i = 0; i < N; i++)
		num[i] = rand() % 100;
}
void mp(int num[])
{
	int i, j, temp;
	int exchange;
	for(i = 0; i < N-1; i++)
	{
		for(j = N-2; j>=i; j--)
			if(num[j+1] < num[j])
			{
				temp = num[j+1];
				num[j+1] = num[j];
				num[j] = temp;
				exchange = 1;
			}
		if(!exchange)
			return;
	}
}
#if 0
void sec(int num[])
{
	int i, j, k;
	int temp;
	for(i =0; i < N; i++)
	{
		k = i;
		for(j = i+1; j < N; i++)
			if(num[j] < num[k])
				k = j;
			if(k != i)
			{
				temp = num[i];
				num[i] = num[k];
				num[k] = temp;
			}
	}
}
#endif
void sec(int num[])
{
	int i, j, temp;
	for(i = 0, j = i+1; i < N && j < N; i++, j++)
	{
		if(num[i] > num[j])
		{
			temp = num[i];
			num[i] = num[j];
			num[j] = temp;
		}
	}
}
void show(int num[],int l, int r)
{
	int i;
	for(i = l; i <= r; i++)
		printf("%3d", num[i]);
	printf("\n");
}
int main(void)
{
	int num[N];
	init(num);
	show(num, 0, N-1);
	mp(num);
	show(num,0, N-1);
	sec(num);
	show(num,0, N-1);
}
