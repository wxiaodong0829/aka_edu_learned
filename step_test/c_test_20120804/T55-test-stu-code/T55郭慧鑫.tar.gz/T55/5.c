#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void fun(char *s)
{
	int i = 0, j = 0, k = 0;
	char c[20];
	int len = strlen(s);

	while(i < len && (isdigit(s[i])))
	{
		i++;
		k = i;
	}
	if(k == len)
		exit(0);
	for(; i < len - 1 ; i++)
	{
		if(isalpha(s[i]))
			c[j++]=s[i];
	}
	c[j]='\0';
	for(j=k+1;j<len ;j++)
	{
		if(isdigit(s[j]))
			s[k++]=s[j];
	}
	//printf("here.........\n");
	s[k]='\0';
	strcat(c,s);
	printf("%s\n",c);
}
#if 1
int main()
{
	char s[]= "abc123edf456";
	printf("%s\n",s);
	fun(s);
}
#endif
