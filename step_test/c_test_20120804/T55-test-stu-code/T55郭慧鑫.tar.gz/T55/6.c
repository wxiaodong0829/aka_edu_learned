#include <stdio.h>
#define N 10

void swap(char *ch,int l, int r)
{
	int temp;
	temp = ch[l];	
	ch[l] = ch[r];
	ch[r] = temp;
}
void reverse(char *ch)
{
	int l, r;
	for(r = 0; ch[r]; r++);
	l = 0; r = r-1;
	while(l < r)
		swap(ch, l++, r--);
	printf("%s\n",ch);
	
}
char *myitoa(unsigned n, char p[])
{
	int i = 0 ;
	int sign;

	if((sign = n) < 0)
		n = -n;
	while(n != 0)
	{
		p[i++] = n % 10 + '0';
		n = n / 10;
	}
	if(sign < 0)
		p[i++] = '-';
	p[i] = '\0';

	printf("%s\n",p);

	reverse(p);
	return p;
}
int main(void)
{
	char p[N];
	myitoa(-123, p);
}
