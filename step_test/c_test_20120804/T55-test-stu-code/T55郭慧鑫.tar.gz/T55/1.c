#include <stdio.h>

void primes(int n)
{
	int i, j, flag;
	printf("   2");
	for(i = 3; i < n; i += 2)
	{
		flag = 1;
		for(j = 2; j * j <= i; j++)
			if(i % j == 0)
			{flag = 0; continue;}
			if(flag == 1)	
				printf("%3d",i);
	}
	printf("\n");
}
int main(void)
{
	primes(100);
	return 0;
}
