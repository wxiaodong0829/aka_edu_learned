#include <stdio.h>
#include <stdlib.h>
#define IF  if(*argv[i] >= '0' && *argv[i] <= '9') push(*argv[i] - '0');
int *a, sp;
void init_stack(int n)
{
	a = malloc(n * sizeof(int));
	sp = 0;
}
int pop(void)
{
	return (a[--sp]);
}
void push(int f)
{
	a[sp++] = f;
}
int main(int argc, char *argv[])
{
	int i, p1;
	char c;
	init_stack(argc);
#if 1

		
	for(i=1; i<argc; i++)
	{
	if (*argv[i] == '#')
		//exit(0);
		break;
	printf("here.........\n");
		if(*argv[i]>='0'&&  *argv[i]<='9')	push(*argv[i]-'0');
		if(*argv[i]=='+')push(pop()+pop());
		if(*argv[i]=='*')push(pop()*pop());	
		if(*argv[i]=='-'){ p1 = pop(); push(p1 - pop());}	
		if(*argv[i]=='/'){ p1 = pop(); push(p1 /  pop());}	
	}
	printf("%d\n",pop());
#endif 
#if 0
	while(1)
	{
		c = *argv[1];
		switch(c)
		{
			case '#': exit(0); break;
			case '+': 
				  for(i = 1; i < argc; i++)
				  {
					  IF push(pop() + pop());
				  }
				  break;
			case '*': 
				  for(i = 1; i < argc; i++)
				  {
					  IF push(pop() * pop());
				  }
				  break;
			case '-': 
				  for(i = 1; i < argc; i++)
				  {
					  IF p1 = pop();
					  push( p1 - pop());
				  }
				  break;

			case '/': 
				  for(i = 1; i < argc; i++)
				  {
					  IF p1 = pop();
					  push( p1 / pop());
				  }
				  break;
		}
	printf("%d\n",pop());
	}
#endif
	return 0;
}		
