#include <stdio.h>
#include <string.h>
//#define N 5
void show(char *ch)
{
	int i;
	int len = strlen(ch);
	for(i = 0; i < len; i++)
	printf("%c",ch[i]);
	printf("\n");
}
int max(char *ch)
{
	int i, k, j;
	int len = strlen(ch);
	char cmax = ch[0];
	char temp;
	for(i = 1; i < len; i++)
	{
		if(cmax < ch[i])
		{
		//temp = cmax;
		cmax = ch[i];
		//ch[i] = cmax;
		k = i;
		}
	}
			
		//printf("%c %d\n",cmax, k);	
		temp = ch[k];
	for(j = k; j >= 0; j--)
		ch[j] = ch[j-1];
	ch[j+1] = temp;
	
}
int main(void)
{
	char ch[] = "ckzyha";
	show(ch);
	max(ch);	
	show(ch);
}
