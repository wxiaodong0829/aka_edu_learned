#include <stdio.h>
#include <string.h>
#define N 20

void swap(char *ch,int l, int r)
{
	int temp;
	temp = ch[l];	
	ch[l] = ch[r];
	ch[r] = temp;
}
void reverse(char *ch)
{
	int l, r;
	for(r = 0; ch[r]; r++);
	l = 0; r = r-1;
	while(l < r)
		swap(ch, l++, r--);
	printf("%s\n",ch);

}
char *myitoa(unsigned n, char p[])
{
	int i = 0 ;
	int sign;

	if((sign = n) < 0)
		n = -n;
	while(n != 0)
	{
		p[i++] = n % 10 + '0';
		n = n / 10;
	}
	if(sign < 0)
		p[i++] = '-';
	p[i] = '\0';

	//printf("%s\n",p);

	//reverse(p);
	return p;
}
void dollars(char *p,char *dest)
{
	int len, i, j, k = 0;
	 myitoa(134534597, p);
	
//	reverse(dest);

	len = strlen(p);
	//printf("%d\n",len);

	strncpy(dest, p, 2);
	dest[2] = '.';
	dest[3] = '\0';
	for(i = 0; i <= strlen(p)-3; i++)
		p[i] = p[i+2];
	p[i] = '\0';
	//printf("dest = %s\n",dest);
	//printf("p = %s\n",p);

	k += 3;
	strncat(dest, p, 3);
	dest[k+3] = ',';
	dest[k+4] = '\0';
	for(i = 0; i<= strlen(p)-4; i++)
		p[i] = p[i+3];
	p[i] = '\0';
	//printf("dest = %s\n",dest);
	//printf("p = %s\n",p);


	while(strlen(p) >= 3)
	{k += 4;
		strncat(dest, p, 3);
		dest[k+4] = ',';
		dest[k+5] = '\0';
		for(i = 0; i<= strlen(p)-4; i++)
			p[i] = p[i+3];
		p[i] = '\0';
		//printf("dest = %s\n",dest);
		//printf("p = %s\n",p);


	}
	dest[k+3] = ',';
	dest[k+4] = '\0';
		strncat(dest,p,strlen(p));
	//printf("dest = %s\n",dest);
	//printf("p = %s\n",p);
	reverse(dest);
	printf("dest = %s\n",dest);

}
int main(void)
{
char p[N];
char dest[100];
	dollars(p, dest);
	return 0;
}
