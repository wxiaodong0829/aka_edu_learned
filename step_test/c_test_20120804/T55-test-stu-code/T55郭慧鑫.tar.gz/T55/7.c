#include <stdio.h>
#include <string.h>

typedef struct stud{
	unsigned short id;
	char name[10];
	int s[4];
	double ave;
}ss;
void readrec()
{
	ss s[10];
	int i;
	s = (struct stud *)malloc (sizeof(struct stud));
	for(i = 0; i < 10; i++)
	{
	scanf("%d",&s[i].id);
	scanf("%s",&s[i].name[10]);
	scanf("%d",&s[i].s[4]);
		
	}	
}
int main(void)
{
	
	return 0;
}
