#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 5
int a[N][N];
int cmp(const void *a, const void *b)
{
	return (*(int *)a - *(int *)b);
}

void init()
{
	int i, j;
	srand(time(NULL));
	for(i = 0; i < N; i++)
		for(j = 0; j < N; j++)
			a[i][j] = rand() % 100;

}
void all()
{
	qsort(a, N * N, sizeof(a[0][0]), cmp);
}
void row()
{
	int i, j, k;
	int temp;
	for(i = 0; i < N; i++)
	{
		qsort( &a[i], N, 4, cmp);
	}
}
#if 0
void row()
{
	int i, j, k;
	int temp;
	for(k = 0; k < N; k++)
	{
		for(i = 0, j = i+1; i < N && j < N; i++, j++)
		{
			if(a[k][i] > a[k][j])
			{
				temp = a[k][i];
				a[k][i] = a[k][j];
				a[k][j] = temp;
			}
			break;
		}
	}
}
#endif
void show()
{
	int i, j;
	for(i = 0; i < N; i++)
	{
		for(j = 0; j < N; j++)
			printf("%3d",a[i][j]);
		printf("\n");
	}
}	
int main(void)
{
	int i, k;
	init();
	show();
#if 1
	printf("row:\n");
	row();
	show();
	printf("all:\n");
	all();
	show();
	printf("\n");
#endif
}
