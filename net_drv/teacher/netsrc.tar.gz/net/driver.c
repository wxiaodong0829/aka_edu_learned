#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/etherdevice.h>
#include "cs8900.h"

MODULE_AUTHOR("akaedu");
MODULE_DESCRIPTION("CS8900A net Driver");
MODULE_LICENSE("GPL");

void cs8900_recv(struct net_device *dev)
{
	
}

irqreturn_t cs8900_interrupt(int irq, void *dev_id)
{
	
}

int cs8900_open(struct net_device *dev)
{

}

int cs8900_stop(struct net_device *dev)
{
	
}

int cs8900_xmit(struct sk_buff *skb, struct net_device *dev)
{
	
}

int cs8900_init(struct net_device *dev) 
{
	
}

int __init akae_init(void)
{
	
}

void __exit akae_exit(void)
{
	
}

module_init(akae_init);
module_exit(akae_exit);
