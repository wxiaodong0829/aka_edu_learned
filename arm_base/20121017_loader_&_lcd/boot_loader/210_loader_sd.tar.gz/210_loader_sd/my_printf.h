
extern int my_printf(const char *format, ...);
