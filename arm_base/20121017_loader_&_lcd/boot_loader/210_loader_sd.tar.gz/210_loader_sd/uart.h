void uart0_init(void);
char uart0_getchar(void);
void uart0_putchar(char c);

