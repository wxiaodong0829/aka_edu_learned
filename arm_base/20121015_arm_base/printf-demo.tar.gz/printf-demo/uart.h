void uart_init(void);

char uart_getchar(void);

void uart_putchar(char c);