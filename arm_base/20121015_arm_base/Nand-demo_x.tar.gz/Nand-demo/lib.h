
void putchar(char c);

int puts(const char * s);

void putchar_hex(char c);

void putint_hex(int n);

char * itoa(int n, char * s);

int myprintf(const char * format, ...);

